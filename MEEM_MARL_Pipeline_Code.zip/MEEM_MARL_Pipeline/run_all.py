"""
MEEM-MARL — Master Pipeline Runner.

Runs the complete experimental pipeline:
  1) Statistical analyses (Tables 2-12)
  2) Visualization (Figures 6-11)
  3) MEEM-MARL deep-learning pipeline (Algorithm 1, Steps 1-9)
  4) Effect quantification and alignment validation against paper-reported values

Usage:
  python run_all.py                # full pipeline
  python run_all.py --skip-meem    # skip the deep-learning pipeline
  python run_all.py --quick        # smaller RL training (10 episodes)
"""
import sys
import argparse
import time
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

import numpy as np
import pandas as pd

from config import RESULTS_DIR, TABLES_DIR, FIGURES_DIR


def run_statistical_analyses() -> dict:
    """Run all statistical analysis modules and save tables."""
    print('\n' + '=' * 65)
    print('  PHASE 1: STATISTICAL ANALYSES (Tables 2-12)')
    print('=' * 65)

    from analysis import descriptive, anova_models, engagement, mediation
    from analysis import moderation, task_type, retention, sem

    results = {}

    t = time.time()
    print('\n[1.1] Table 2 — Baseline comparison...')
    results['table2'], results['pretest'] = descriptive.run()
    print(f'    ✓ Generated table2_baseline.csv ({time.time()-t:.2f}s)')

    t = time.time()
    print('\n[1.2] Tables 3-4 — Moral cognition / emotion / behavioral intention ANOVA...')
    t3, t4, rm, d_summary, posthoc = anova_models.run()
    results['table3'] = t3
    results['table4'] = t4
    results['rm_summary'] = rm
    results['d_summary'] = d_summary
    print(f'    ✓ Generated table3_moral_cognition.csv, table4_emotion_intention.csv ({time.time()-t:.2f}s)')

    t = time.time()
    print('\n[1.3] Table 5 — Engagement metrics...')
    results['table5'], results['aoi'] = engagement.run()
    print(f'    ✓ Generated table5_engagement.csv ({time.time()-t:.2f}s)')

    t = time.time()
    print('\n[1.4] Tables 6-7 — Physiological indicators and mediation decomposition...')
    results['table6'], results['table7'], results['mediation_detail'] = mediation.run()
    print(f'    ✓ Generated table6_physiological.csv, table7_mediation.csv ({time.time()-t:.2f}s)')

    t = time.time()
    print('\n[1.5] Table 8 — Moderation effects...')
    results['table8'], results['slopes'] = moderation.run()
    print(f'    ✓ Generated table8_moderation.csv ({time.time()-t:.2f}s)')

    t = time.time()
    print('\n[1.6] Table 9 — Task type analysis...')
    results['table9'] = task_type.run()
    print(f'    ✓ Generated table9_task_type.csv ({time.time()-t:.2f}s)')

    t = time.time()
    print('\n[1.7] Table 10 — Long-term retention...')
    results['table10'], results['forgetting'] = retention.run()
    print(f'    ✓ Generated table10_retention.csv ({time.time()-t:.2f}s)')

    t = time.time()
    print('\n[1.8] SEM fit indices + Table 12 — Design objective validation...')
    results['sem_fit'], results['table12'] = sem.run()
    print(f'    ✓ Generated sem_fit_indices.csv, table12_design_validation.csv ({time.time()-t:.2f}s)')

    print('\n  All statistical tables saved to results/tables/')
    return results


def run_visualizations() -> list:
    """Generate all 6 figures (Fig 6-11)."""
    print('\n' + '=' * 65)
    print('  PHASE 2: VISUALIZATION (Figures 6-11)')
    print('=' * 65)

    from visualization import (fig6_baseline, fig7_main_effect, fig8_engagement,
                                  fig9_mediation, fig10_moderation, fig11_retention)

    figure_paths = []
    for i, (label, module) in enumerate([
        ('Figure 6 — Baseline Comparison',         fig6_baseline),
        ('Figure 7 — Main Effect & Effect Sizes',  fig7_main_effect),
        ('Figure 8 — Engagement Multi-Panel',      fig8_engagement),
        ('Figure 9 — Mediation & SEM Pathways',    fig9_mediation),
        ('Figure 10 — Moderation & Boundaries',    fig10_moderation),
        ('Figure 11 — Long-term Retention',        fig11_retention),
    ], start=1):
        t = time.time()
        print(f'\n[2.{i}] {label}...')
        try:
            path = module.render()
            figure_paths.append(path)
            print(f'    ✓ Saved {path} ({time.time()-t:.2f}s)')
        except Exception as e:
            print(f'    ✗ ERROR: {e}')
            import traceback
            traceback.print_exc()
    print(f'\n  All figures saved to results/figures/')
    return figure_paths


def run_meem_pipeline(n_episodes: int = 50) -> dict:
    """Run the MEEM-MARL Algorithm 1 deep-learning pipeline."""
    print('\n' + '=' * 65)
    print('  PHASE 3: MEEM-MARL PIPELINE (Algorithm 1, Steps 1-9)')
    print('=' * 65)
    from meem.pipeline import run_full_pipeline
    return run_full_pipeline(n_rl_episodes=n_episodes, verbose=True)


def validate_alignment_with_paper(analysis_results: dict) -> pd.DataFrame:
    """Validate that key statistical outputs match paper-reported values."""
    print('\n' + '=' * 65)
    print('  PHASE 4: ALIGNMENT VALIDATION (vs Paper-Reported Values)')
    print('=' * 65)
    from config import (TARGET_COHEN_D, TARGET_SEM_FIT, TARGET_MEDIATION,
                          TARGET_RETENTION)

    rows = []

    # Cohen's d alignment
    d_df = analysis_results.get('d_summary')
    if d_df is not None:
        mc_row = d_df[d_df['Outcome'] == 'Moral Cognition'].iloc[0]
        for g_en, target in TARGET_COHEN_D.items():
            actual_str = mc_row.get(g_en, 'N/A')
            try:
                # Remove '(within)' suffix if present
                actual = float(str(actual_str).split()[0].rstrip('(within)'))
            except Exception:
                actual = float('nan')
            diff = abs(actual - target)
            status = '✓' if diff < 0.10 else '⚠' if diff < 0.30 else '✗'
            rows.append({
                'Metric': f"Cohen's d (MC, {g_en})",
                'Paper Target': f"{target:.2f}",
                'This Study': f"{actual:.2f}",
                'Δ': f"{diff:.3f}",
                'Status': status,
            })

    # SEM fit indices
    sem_fit = analysis_results.get('sem_fit')
    if sem_fit is not None:
        for index_name, target_value in [
            ('χ²/df', TARGET_SEM_FIT['chi2_df']),
            ('CFI', TARGET_SEM_FIT['cfi']),
            ('TLI', TARGET_SEM_FIT['tli']),
            ('RMSEA', TARGET_SEM_FIT['rmsea']),
        ]:
            try:
                row = sem_fit[sem_fit['Fit Index'] == index_name].iloc[0]
                actual_str = row['Value (this study)']
                actual = float(actual_str)
            except (IndexError, ValueError, KeyError):
                actual = float('nan')
            diff = abs(actual - target_value)
            status = '✓' if diff < 0.05 else '⚠' if diff < 0.15 else '✗'
            rows.append({
                'Metric': f'SEM Fit: {index_name}',
                'Paper Target': f"{target_value:.3f}",
                'This Study': f"{actual:.3f}",
                'Δ': f"{diff:.3f}",
                'Status': status,
            })

    # Mediation %
    t7 = analysis_results.get('table7')
    if t7 is not None:
        for path, target in TARGET_MEDIATION.items():
            path_name = path.replace('_', ' → ')
            # Find matching row
            for _, row in t7.iterrows():
                if path_name.replace('VI → SP → ME', 'VI → SP → ME').lower() in row['Path'].lower():
                    actual_str = str(row['Mediation %']).rstrip('%')
                    try:
                        actual = float(actual_str)
                    except ValueError:
                        actual = float('nan')
                    diff = abs(actual - target['pct'])
                    status = '✓' if diff < 5 else '⚠' if diff < 15 else '✗'
                    rows.append({
                        'Metric': f"Mediation %: {row['Path']}",
                        'Paper Target': f"{target['pct']:.1f}%",
                        'This Study': f"{actual:.1f}%",
                        'Δ': f"{diff:.2f}",
                        'Status': status,
                    })
                    break

    # 8-week retention
    forgetting = analysis_results.get('forgetting')
    if forgetting is not None:
        for g_en in ['Control', 'Virtual Idol', 'Traditional']:
            try:
                row = forgetting[forgetting['Group'] == g_en].iloc[0]
                actual = float(row['T2_8wk'])
            except Exception:
                actual = float('nan')
            target = TARGET_RETENTION['8wk'][g_en]['cog']
            diff = abs(actual - target)
            status = '✓' if diff < 3 else '⚠' if diff < 8 else '✗'
            rows.append({
                'Metric': f"8-wk Retention (Cog, {g_en})",
                'Paper Target': f"{target:.1f}%",
                'This Study': f"{actual:.1f}%",
                'Δ': f"{diff:.2f}",
                'Status': status,
            })

    df = pd.DataFrame(rows)
    df.to_csv(TABLES_DIR / 'alignment_validation.csv',
               index=False, encoding='utf-8-sig')

    print('\n' + df.to_string(index=False))
    n_ok = (df['Status'] == '✓').sum()
    n_warn = (df['Status'] == '⚠').sum()
    n_bad = (df['Status'] == '✗').sum()
    print(f'\n  Summary: {n_ok} ✓ aligned, {n_warn} ⚠ within tolerance, '
           f'{n_bad} ✗ misaligned')
    return df


def main():
    parser = argparse.ArgumentParser(description='MEEM-MARL master runner')
    parser.add_argument('--skip-meem', action='store_true',
                          help='Skip the deep-learning MEEM-MARL pipeline')
    parser.add_argument('--skip-viz', action='store_true',
                          help='Skip figure generation')
    parser.add_argument('--quick', action='store_true',
                          help='Use 10 RL episodes (much faster)')
    args = parser.parse_args()

    print('\n' + '#' * 65)
    print('#   MEEM-MARL EXPERIMENTAL PIPELINE — Master Runner              #')
    print('#' * 65)
    print(f'\n  Output directory: {RESULTS_DIR}')

    t_total = time.time()

    # Phase 1: Statistical analyses
    analysis_results = run_statistical_analyses()

    # Phase 2: Visualizations
    if not args.skip_viz:
        figure_paths = run_visualizations()

    # Phase 3: MEEM-MARL pipeline
    if not args.skip_meem:
        n_episodes = 10 if args.quick else 50
        meem_results = run_meem_pipeline(n_episodes=n_episodes)

    # Phase 4: Validation
    validation_df = validate_alignment_with_paper(analysis_results)

    elapsed = time.time() - t_total
    print('\n' + '#' * 65)
    print(f'#   PIPELINE COMPLETE — total time: {elapsed:.1f}s')
    print(f'#   Tables:  {TABLES_DIR}')
    print(f'#   Figures: {FIGURES_DIR}')
    print('#' * 65)


if __name__ == '__main__':
    main()
