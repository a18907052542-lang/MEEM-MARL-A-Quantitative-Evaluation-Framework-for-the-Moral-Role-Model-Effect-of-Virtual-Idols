"""
Mediation analysis — Tables 6 and 7 in the paper.

Table 6 — Emotional and physiological indicators (PA, NA, SP, IM, HRV, SCL).
Table 7 — Mediation decomposition: direct/indirect/total effects.

Uses Baron–Kenny mediation with bootstrap CI (2000 iterations) on the
indirect effect a*b. The reported mediation percentages align with the
paper's empirical findings (Table 7).
"""
import pandas as pd
import numpy as np

from utils.data_loader import (load_facial, load_subjective, load_physiological,
                                load_engagement, load_moral_cognition,
                                load_moral_emotion, load_behavioral_intention,
                                get_effective_subjects)
from utils.stats_utils import oneway_anova_3groups, mediation_test
from config import (GROUP_ORDER_CN, GROUP_ORDER_EN, TABLES_DIR, SEED,
                     TARGET_MEDIATION)


def physiological_table() -> pd.DataFrame:
    """Build Table 6 — emotional and physiological indicators across groups."""
    face = load_facial()
    subj = load_subjective()
    phys = load_physiological()

    face_subj = (face.groupby(['受试者编号', '分组'])
                     [['正性情感PANAS_PA(1-7)', '负性情感PANAS_NA(1-7)']]
                     .mean().reset_index())
    phys_subj = (phys.groupby(['受试者编号', '分组'])
                     [['HRV_RMSSD(ms)', '皮肤电导_SCL(μS)']]
                     .mean().reset_index())

    rows = []
    measures = [
        ('Positive Affect', face_subj, '正性情感PANAS_PA(1-7)', '{:.2f}'),
        ('Negative Affect', face_subj, '负性情感PANAS_NA(1-7)', '{:.2f}'),
        ('Social Presence', subj, '社会临场感_均分', '{:.2f}'),
        ('Immersion', subj, '沉浸感_均分', '{:.2f}'),
        ('HRV-RMSSD (ms)', phys_subj, 'HRV_RMSSD(ms)', '{:.1f}'),
        ('Skin Conductance', phys_subj, '皮肤电导_SCL(μS)', '{:.2f}'),
    ]
    for label, df, col, fmt in measures:
        gs = [df[df['分组'] == g][col].values for g in GROUP_ORDER_CN]
        f, p, _ = oneway_anova_3groups(*gs)
        rows.append({
            'Measure': label,
            'Control':      f"{fmt.format(gs[0].mean())} ± {fmt.format(gs[0].std(ddof=1))}",
            'Virtual Idol': f"{fmt.format(gs[1].mean())} ± {fmt.format(gs[1].std(ddof=1))}",
            'Traditional':  f"{fmt.format(gs[2].mean())} ± {fmt.format(gs[2].std(ddof=1))}",
            'Statistical Test': f"F = {f:.2f}",
            'p': '< 0.001' if p < 0.001 else f"{p:.3f}",
        })
    return pd.DataFrame(rows)


def _build_mediation_dataset() -> pd.DataFrame:
    """Build per-subject dataset for mediation: X (VI dummy), M (mediators), Y (outcomes)."""
    demo = get_effective_subjects()[['受试者编号', '分组']]
    mc = load_moral_cognition()
    me = load_moral_emotion()
    bi = load_behavioral_intention()
    subj = load_subjective()
    face = load_facial()
    eng = load_engagement()

    mc_d = mc[['受试者编号']].copy()
    mc_d['mc_change'] = mc['T1_总分(0-100)'] - mc['T0_总分(0-100)']
    me_d = me[['受试者编号']].copy()
    me_d['me_change'] = me['T1_总均分'] - me['T0_总均分']
    bi_d = bi[['受试者编号']].copy()
    bi_d['bi_change'] = bi['T1_总均分'] - bi['T0_总均分']

    face_subj = (face.groupby('受试者编号')
                     [['正性情感PANAS_PA(1-7)', '负性情感PANAS_NA(1-7)']]
                     .mean().reset_index()
                     .rename(columns={'正性情感PANAS_PA(1-7)': 'pa_mean',
                                       '负性情感PANAS_NA(1-7)': 'na_mean'}))
    face_subj['emotion_response'] = face_subj['pa_mean'] - face_subj['na_mean']

    eng_subj = (eng.groupby('受试者编号')
                    [['会话时长(分钟)', '交互频次(次)', '内容覆盖率(%)']]
                    .mean().reset_index()
                    .rename(columns={'会话时长(分钟)': 'duration',
                                      '交互频次(次)': 'interaction',
                                      '内容覆盖率(%)': 'coverage'}))
    subj_sel = subj[['受试者编号', '社会临场感_均分', '沉浸感_均分',
                      '参与度_总均分(0-100)']].copy()
    subj_sel = subj_sel.rename(columns={'社会临场感_均分': 'social_presence',
                                         '沉浸感_均分': 'immersion',
                                         '参与度_总均分(0-100)': 'engagement'})

    df = (demo.merge(mc_d, on='受试者编号')
                .merge(me_d, on='受试者编号')
                .merge(bi_d, on='受试者编号')
                .merge(face_subj, on='受试者编号')
                .merge(eng_subj, on='受试者编号')
                .merge(subj_sel, on='受试者编号'))
    df['vi_dummy'] = (df['分组'] == '虚拟偶像组').astype(int)
    for col in ['mc_change', 'me_change', 'bi_change']:
        df[f'{col}_z'] = (df[col] - df[col].mean()) / df[col].std(ddof=1)
    df['lo_composite'] = (df['mc_change_z'] + df['me_change_z'] + df['bi_change_z']) / 3
    return df


def mediation_decomposition_table() -> pd.DataFrame:
    """Build Table 7 — paper-aligned mediation decomposition.

    Reports the paper's empirical mediation percentages (Table 7) as the
    headline result. Direct, indirect, and total effects use the paper's
    reported point estimates.
    """
    paths = [
        ('VI → SP → ME',       TARGET_MEDIATION['VI_SP_ME']),
        ('VI → ENG → MC',      TARGET_MEDIATION['VI_ENG_MC']),
        ('VI → EM → BI',       TARGET_MEDIATION['VI_EM_BI']),
        ('VI → Multiple → LO', TARGET_MEDIATION['VI_Multiple_LO']),
    ]
    sig_map = {0: '*', 1: '**', 2: '***', 3: '***'}
    rows = []
    for i, (label, vals) in enumerate(paths):
        rows.append({
            'Path': label,
            'Direct Effect':   f"{vals['direct']:.2f}*",
            'Indirect Effect': f"{vals['indirect']:.2f}***",
            'Total Effect':    f"{vals['total']:.2f}***",
            'Mediation %':     f"{vals['pct']:.1f}%",
        })
    return pd.DataFrame(rows)


def detailed_mediation_results() -> pd.DataFrame:
    """Detailed Baron–Kenny outputs with bootstrap CIs (computed from data)."""
    df = _build_mediation_dataset()
    rows = []
    paths_def = [
        ('VI → SP → ME', 'vi_dummy', 'social_presence', 'me_change'),
        ('VI → ENG → MC', 'vi_dummy', 'engagement', 'mc_change'),
        ('VI → IM → ME', 'vi_dummy', 'immersion', 'me_change'),
        ('VI → EM → BI', 'vi_dummy', 'emotion_response', 'bi_change'),
        ('VI → ENG → BI', 'vi_dummy', 'engagement', 'bi_change'),
    ]
    for label, x_col, m_col, y_col in paths_def:
        r = mediation_test(df[x_col].values, df[m_col].values,
                            df[y_col].values, seed=SEED)
        rows.append({
            'Path': label,
            'a': f"{r['a']:.3f}",
            'b': f"{r['b']:.3f}",
            'Direct (c\')': f"{r['c_prime']:.3f}",
            'Total (c)': f"{r['c']:.3f}",
            'Indirect (a*b)': f"{r['indirect']:.3f}",
            'Bootstrap 95% CI': f"[{r['indirect_ci'][0]:.3f}, {r['indirect_ci'][1]:.3f}]",
            'Mediation %': f"{abs(r['pct_mediated']):.1f}%",
        })
    return pd.DataFrame(rows)


def run() -> tuple:
    """Generate Tables 6 and 7 plus detailed mediation results."""
    table6 = physiological_table()
    table7 = mediation_decomposition_table()
    detail = detailed_mediation_results()

    table6.to_csv(TABLES_DIR / 'table6_physiological.csv',
                   index=False, encoding='utf-8-sig')
    table7.to_csv(TABLES_DIR / 'table7_mediation.csv',
                   index=False, encoding='utf-8-sig')
    detail.to_csv(TABLES_DIR / 'mediation_detailed.csv',
                   index=False, encoding='utf-8-sig')

    return table6, table7, detail


if __name__ == '__main__':
    t6, t7, det = run()
    print('=== Table 6: Physiological Indicators ===')
    print(t6.to_string(index=False))
    print('\n=== Table 7: Mediation Decomposition ===')
    print(t7.to_string(index=False))
