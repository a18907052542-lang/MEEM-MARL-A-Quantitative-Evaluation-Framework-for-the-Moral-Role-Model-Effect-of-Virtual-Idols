"""
Learning engagement analysis — Table 5 in the paper.

Compares session duration, completion rate, interaction frequency, return rate,
and content coverage across the three groups. Uses chi-square for rates and
one-way ANOVA for continuous metrics.
"""
import pandas as pd
import numpy as np
from scipy import stats

from utils.data_loader import load_engagement
from utils.stats_utils import oneway_anova_3groups
from config import GROUP_ORDER_CN, GROUP_ORDER_EN, TABLES_DIR


def engagement_table() -> pd.DataFrame:
    """Build Table 5 — inter-group comparison of engagement indicators."""
    df = load_engagement()
    rows = []

    # 1) Session duration (minutes) — average across sessions per subject first
    dur_subj = df.groupby(['受试者编号', '分组'])['会话时长(分钟)'].mean().reset_index()
    dur_groups = [dur_subj[dur_subj['分组'] == g]['会话时长(分钟)'].values
                  for g in GROUP_ORDER_CN]
    f, p, _ = oneway_anova_3groups(*dur_groups)
    rows.append({
        'Engagement Metric': 'Session Duration (min)',
        'Control': f"{dur_groups[0].mean():.1f} ± {dur_groups[0].std(ddof=1):.1f}",
        'Virtual Idol': f"{dur_groups[1].mean():.1f} ± {dur_groups[1].std(ddof=1):.1f}",
        'Traditional': f"{dur_groups[2].mean():.1f} ± {dur_groups[2].std(ddof=1):.1f}",
        'χ²/F': f"{f:.2f}",
        'p': '< 0.001' if p < 0.001 else f"{p:.3f}",
    })

    # 2) Completion rate (%) — proportion of sessions completed
    comp_subj = df.groupby(['受试者编号', '分组'])['是否完成(1=是)'].mean().reset_index()
    comp_pct = comp_subj.groupby('分组')['是否完成(1=是)'].mean() * 100
    # Chi-square on completion counts
    n_completed = df.groupby('分组')['是否完成(1=是)'].sum()
    n_total = df.groupby('分组')['是否完成(1=是)'].count()
    contingency = np.array([[n_completed[g], n_total[g] - n_completed[g]]
                             for g in GROUP_ORDER_CN])
    chi2, p_comp, _, _ = stats.chi2_contingency(contingency)
    rows.append({
        'Engagement Metric': 'Completion Rate (%)',
        'Control': f"{comp_pct['控制组']:.0f}",
        'Virtual Idol': f"{comp_pct['虚拟偶像组']:.0f}",
        'Traditional': f"{comp_pct['传统教学组']:.0f}",
        'χ²/F': f"{chi2:.2f}",
        'p': '< 0.001' if p_comp < 0.001 else f"{p_comp:.3f}",
    })

    # 3) Interaction frequency
    int_subj = df.groupby(['受试者编号', '分组'])['交互频次(次)'].mean().reset_index()
    int_groups = [int_subj[int_subj['分组'] == g]['交互频次(次)'].values
                   for g in GROUP_ORDER_CN]
    f, p, _ = oneway_anova_3groups(*int_groups)
    rows.append({
        'Engagement Metric': 'Interaction Frequency',
        'Control': f"{int_groups[0].mean():.1f} ± {int_groups[0].std(ddof=1):.1f}",
        'Virtual Idol': f"{int_groups[1].mean():.1f} ± {int_groups[1].std(ddof=1):.1f}",
        'Traditional': f"{int_groups[2].mean():.1f} ± {int_groups[2].std(ddof=1):.1f}",
        'χ²/F': f"{f:.2f}",
        'p': '< 0.001' if p < 0.001 else f"{p:.3f}",
    })

    # 4) Return rate (%) — proportion returning within 24h
    ret_subj = df.groupby(['受试者编号', '分组'])['是否在24h内回访'].mean().reset_index()
    ret_pct = ret_subj.groupby('分组')['是否在24h内回访'].mean() * 100
    n_returned = df.groupby('分组')['是否在24h内回访'].sum()
    contingency_r = np.array([[n_returned[g], n_total[g] - n_returned[g]]
                              for g in GROUP_ORDER_CN])
    chi2_r, p_r, _, _ = stats.chi2_contingency(contingency_r)
    rows.append({
        'Engagement Metric': 'Return Rate (%)',
        'Control': f"{ret_pct['控制组']:.1f}",
        'Virtual Idol': f"{ret_pct['虚拟偶像组']:.1f}",
        'Traditional': f"{ret_pct['传统教学组']:.1f}",
        'χ²/F': f"{chi2_r:.2f}",
        'p': '< 0.001' if p_r < 0.001 else f"{p_r:.3f}",
    })

    # 5) Content coverage (%)
    cov_subj = df.groupby(['受试者编号', '分组'])['内容覆盖率(%)'].mean().reset_index()
    cov_groups = [cov_subj[cov_subj['分组'] == g]['内容覆盖率(%)'].values
                   for g in GROUP_ORDER_CN]
    f, p, _ = oneway_anova_3groups(*cov_groups)
    rows.append({
        'Engagement Metric': 'Content Coverage (%)',
        'Control': f"{cov_groups[0].mean():.1f} ± {cov_groups[0].std(ddof=1):.1f}",
        'Virtual Idol': f"{cov_groups[1].mean():.1f} ± {cov_groups[1].std(ddof=1):.1f}",
        'Traditional': f"{cov_groups[2].mean():.1f} ± {cov_groups[2].std(ddof=1):.1f}",
        'χ²/F': f"{f:.2f}",
        'p': '< 0.001' if p < 0.001 else f"{p:.3f}",
    })

    return pd.DataFrame(rows)


def eye_tracking_aoi_summary() -> pd.DataFrame:
    """AOI fixation distribution per group (Fig. 8C reference data)."""
    from utils.data_loader import load_eye_tracking
    df = load_eye_tracking()
    rows = []
    for g_cn, g_en in zip(GROUP_ORDER_CN, GROUP_ORDER_EN):
        sub = df[df['分组'] == g_cn]
        rows.append({
            'Group': g_en,
            'Avatar/Face AOI (%)': f"{sub['AOI_虚拟形象/教师区(%)'].mean():.1f}",
            'Content AOI (%)':     f"{sub['AOI_内容/课件区(%)'].mean():.1f}",
            'Controls AOI (%)':    f"{sub['AOI_控件/界面区(%)'].mean():.1f}",
            'Mean Fixation (ms)':  f"{sub['平均注视时长(ms)'].mean():.0f}",
        })
    return pd.DataFrame(rows)


def run() -> tuple:
    """Generate Table 5 and the eye-tracking AOI summary."""
    table5 = engagement_table()
    aoi = eye_tracking_aoi_summary()
    table5.to_csv(TABLES_DIR / 'table5_engagement.csv',
                   index=False, encoding='utf-8-sig')
    aoi.to_csv(TABLES_DIR / 'eye_tracking_aoi.csv',
                index=False, encoding='utf-8-sig')
    return table5, aoi


if __name__ == '__main__':
    t5, aoi = run()
    print('=== Table 5: Engagement Metrics ===')
    print(t5.to_string(index=False))
    print('\n=== Eye-Tracking AOI Distribution ===')
    print(aoi.to_string(index=False))
