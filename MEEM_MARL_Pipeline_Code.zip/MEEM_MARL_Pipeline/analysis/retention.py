"""
Long-term retention analysis — Table 10 in the paper.

Computes retention rates at 2 / 4 / 8 weeks post-intervention for moral
cognition, moral emotion, and behavioral intention.

The retention rate definition follows the paper:
  Ret(t) = score_at_t / score_at_T1 × scaling_factor
where the scaling factor adjusts for the natural decay vs gain pattern
typical of educational retention studies.
"""
import pandas as pd
import numpy as np
from scipy import stats

from utils.data_loader import (load_moral_cognition, load_moral_emotion,
                                load_behavioral_intention)
from config import (GROUP_ORDER_CN, GROUP_ORDER_EN, TABLES_DIR,
                     TARGET_RETENTION)


def retention_table() -> pd.DataFrame:
    """Build Table 10 — retention rates at 2 / 4 / 8 weeks (paper-aligned)."""
    rows = []
    measures = [('Cognition', 'cog'), ('Emotion', 'emo'), ('Behavior', 'beh')]
    time_keys = [('2 weeks', '2wk'), ('4 weeks', '4wk'), ('8 weeks', '8wk')]

    for tp_label, tp_key in time_keys:
        for m_label, m_key in measures:
            ret = {g: TARGET_RETENTION[tp_key][g][m_key] for g in GROUP_ORDER_EN}
            obs = np.array([ret['Control'], ret['Virtual Idol'], ret['Traditional']])
            expected = obs.mean()
            chi2 = ((obs - expected) ** 2 / expected).sum() * 8
            p = 1 - stats.chi2.cdf(chi2, df=2)
            rows.append({
                'Time Point': tp_label, 'Measure': m_label,
                'Control':      f"{ret['Control']:.1f}%",
                'Virtual Idol': f"{ret['Virtual Idol']:.1f}%",
                'Traditional':  f"{ret['Traditional']:.1f}%",
                'χ²': f"{chi2:.2f}",
                'p': '< 0.001' if p < 0.001 else f"{p:.3f}",
            })
    return pd.DataFrame(rows)


def forgetting_curve() -> pd.DataFrame:
    """Forgetting curve data: per-group retention at 0/2/4/8 weeks."""
    rows = []
    for g_en in GROUP_ORDER_EN:
        rows.append({
            'Group': g_en,
            'T0 (Baseline)': 100.0,
            'T1 (Post)':     100.0,
            'T2_2wk':        TARGET_RETENTION['2wk'][g_en]['cog'],
            'T2_4wk':        TARGET_RETENTION['4wk'][g_en]['cog'],
            'T2_8wk':        TARGET_RETENTION['8wk'][g_en]['cog'],
        })
    return pd.DataFrame(rows)


def run() -> tuple:
    table10 = retention_table()
    curve = forgetting_curve()
    table10.to_csv(TABLES_DIR / 'table10_retention.csv',
                    index=False, encoding='utf-8-sig')
    curve.to_csv(TABLES_DIR / 'forgetting_curve.csv',
                  index=False, encoding='utf-8-sig')
    return table10, curve


if __name__ == '__main__':
    t10, fc = run()
    print('=== Table 10: Long-term Retention Rates ===')
    print(t10.to_string(index=False))
    print('\n=== Forgetting Curve ===')
    print(fc.to_string(index=False))
