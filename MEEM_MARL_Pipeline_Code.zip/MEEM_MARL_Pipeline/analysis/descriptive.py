"""
Descriptive statistics and baseline comparison — Table 2 in the paper.

Verifies internal validity by testing whether the three groups differ on
baseline demographic and prior-knowledge variables. Non-significant
between-group differences (p > 0.05) confirm successful random assignment.
"""
import pandas as pd
import numpy as np
from scipy import stats

from utils.data_loader import (get_effective_subjects, load_moral_cognition,
                                load_moral_emotion, load_behavioral_intention)
from utils.stats_utils import oneway_anova_3groups, chi_squared_proportions
from config import GROUP_ORDER_CN, GROUP_ORDER_EN, TABLES_DIR


def baseline_comparison() -> pd.DataFrame:
    """Build Table 2 — between-group comparison of baseline characteristics."""
    demo = get_effective_subjects()
    mc = load_moral_cognition()

    # Slice by group
    groups = [demo[demo['分组'] == g] for g in GROUP_ORDER_CN]

    rows = []

    # 1) Age
    ages = [g['年龄'].values for g in groups]
    f, p, _ = oneway_anova_3groups(*ages)
    rows.append({
        'Variable': 'Age (M ± SD)',
        'Control': f"{ages[0].mean():.1f} ± {ages[0].std(ddof=1):.1f}",
        'Virtual Idol': f"{ages[1].mean():.1f} ± {ages[1].std(ddof=1):.1f}",
        'Traditional': f"{ages[2].mean():.1f} ± {ages[2].std(ddof=1):.1f}",
        'F/χ²': f"{f:.3f}",
        'p': f"{p:.3f}",
    })

    # 2) Gender (M/F counts)
    gender_rows = []
    chi_table = []
    for g in groups:
        male = (g['性别'] == '男').sum()
        female = (g['性别'] == '女').sum()
        gender_rows.append(f"{male} / {female}")
        chi_table.append([male, female])
    chi2, p_g, _, _ = stats.chi2_contingency(chi_table)
    rows.append({
        'Variable': 'Gender (M/F)',
        'Control': gender_rows[0],
        'Virtual Idol': gender_rows[1],
        'Traditional': gender_rows[2],
        'F/χ²': f"{chi2:.3f}",
        'p': f"{p_g:.3f}",
    })

    # 3) Prior moral knowledge
    pk_col = '先验道德知识基线分（0-100）'
    pks = [g[pk_col].values for g in groups]
    f_pk, p_pk, _ = oneway_anova_3groups(*pks)
    rows.append({
        'Variable': 'Prior Knowledge',
        'Control': f"{pks[0].mean():.1f} ± {pks[0].std(ddof=1):.1f}",
        'Virtual Idol': f"{pks[1].mean():.1f} ± {pks[1].std(ddof=1):.1f}",
        'Traditional': f"{pks[2].mean():.1f} ± {pks[2].std(ddof=1):.1f}",
        'F/χ²': f"{f_pk:.3f}",
        'p': f"{p_pk:.3f}",
    })

    # 4) Tech proficiency
    tp_col = '技术熟练度（1-5）'
    tps = [g[tp_col].values for g in groups]
    f_tp, p_tp, _ = oneway_anova_3groups(*tps)
    rows.append({
        'Variable': 'Tech Proficiency',
        'Control': f"{tps[0].mean():.1f} ± {tps[0].std(ddof=1):.1f}",
        'Virtual Idol': f"{tps[1].mean():.1f} ± {tps[1].std(ddof=1):.1f}",
        'Traditional': f"{tps[2].mean():.1f} ± {tps[2].std(ddof=1):.1f}",
        'F/χ²': f"{f_tp:.3f}",
        'p': f"{p_tp:.3f}",
    })

    # 5) Learning motivation
    lm_col = '学习动机（1-5）'
    lms = [g[lm_col].values for g in groups]
    f_lm, p_lm, _ = oneway_anova_3groups(*lms)
    rows.append({
        'Variable': 'Learning Motivation',
        'Control': f"{lms[0].mean():.1f} ± {lms[0].std(ddof=1):.1f}",
        'Virtual Idol': f"{lms[1].mean():.1f} ± {lms[1].std(ddof=1):.1f}",
        'Traditional': f"{lms[2].mean():.1f} ± {lms[2].std(ddof=1):.1f}",
        'F/χ²': f"{f_lm:.3f}",
        'p': f"{p_lm:.3f}",
    })

    table = pd.DataFrame(rows)
    return table


def pretest_equivalence() -> pd.DataFrame:
    """Verify no significant pretest differences across the three outcome variables.
    Reports F(2,183) for moral cognition / emotion / behavioral intention.
    """
    mc = load_moral_cognition()
    me = load_moral_emotion()
    bi = load_behavioral_intention()

    out = []
    for label, df, col in [('Moral Cognition', mc, 'T0_总分(0-100)'),
                            ('Moral Emotion',   me, 'T0_总均分'),
                            ('Behavioral Intention', bi, 'T0_总均分')]:
        groups = [df[df['分组'] == g][col].values for g in GROUP_ORDER_CN]
        f, p, _ = oneway_anova_3groups(*groups)
        out.append({
            'Outcome': label,
            'F(2,183)': f"{f:.3f}",
            'p': f"{p:.3f}",
            'Equivalent (p>0.05)?': 'Yes' if p > 0.05 else 'No',
        })
    return pd.DataFrame(out)


def run() -> tuple:
    """Run descriptive analyses and write Table 2."""
    table2 = baseline_comparison()
    pretest = pretest_equivalence()
    table2.to_csv(TABLES_DIR / 'table2_baseline.csv', index=False, encoding='utf-8-sig')
    pretest.to_csv(TABLES_DIR / 'table2b_pretest_equivalence.csv',
                    index=False, encoding='utf-8-sig')
    return table2, pretest


if __name__ == '__main__':
    t2, pt = run()
    print('=== Table 2: Baseline Comparison ===')
    print(t2.to_string(index=False))
    print('\n=== Pretest Equivalence (all p > 0.05 confirms random assignment) ===')
    print(pt.to_string(index=False))
