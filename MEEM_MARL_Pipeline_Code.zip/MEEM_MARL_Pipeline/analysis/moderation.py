"""
Moderation analysis — Table 8 in the paper.

Tests whether individual characteristics (technology proficiency, prior
experience, gender, age) moderate the virtual-idol treatment effect on the
three outcome measures.

Statistical model: hierarchical regression with interaction terms:
  Y = b0 + b1·X + b2·M + b3·X·M + ε
where ΔR² quantifies the variance explained by the interaction term.
"""
import pandas as pd
import numpy as np
from scipy import stats

from utils.data_loader import (get_effective_subjects, load_moral_cognition,
                                load_moral_emotion, load_behavioral_intention,
                                load_engagement)
from config import GROUP_ORDER_CN, TABLES_DIR


def _hierarchical_regression(y: np.ndarray, x: np.ndarray, m: np.ndarray
                              ) -> dict:
    """Hierarchical regression: Step 1 = X+M; Step 2 = X+M+X·M. Returns ΔR² and t-test on interaction."""
    x_c = x - x.mean()
    m_c = m - m.mean()
    n = len(y)
    ones = np.ones(n)

    # Step 1: y on X, M
    X1 = np.column_stack([ones, x_c, m_c])
    coef1, *_ = np.linalg.lstsq(X1, y, rcond=None)
    fit1 = X1 @ coef1
    ss_res1 = ((y - fit1) ** 2).sum()
    ss_tot = ((y - y.mean()) ** 2).sum()
    r2_step1 = 1 - ss_res1 / ss_tot

    # Step 2: y on X, M, X·M
    X2 = np.column_stack([ones, x_c, m_c, x_c * m_c])
    coef2, *_ = np.linalg.lstsq(X2, y, rcond=None)
    fit2 = X2 @ coef2
    ss_res2 = ((y - fit2) ** 2).sum()
    r2_step2 = 1 - ss_res2 / ss_tot
    delta_r2 = r2_step2 - r2_step1

    # t-test on interaction coefficient
    b_int = coef2[3]
    df = n - 4
    if df <= 0:
        return {'B': 0, 'SE': 0, 't': 0, 'p': 1, 'ci': (0, 0), 'delta_r2': 0}
    mse = ss_res2 / df
    XtX_inv = np.linalg.pinv(X2.T @ X2)
    se = np.sqrt(mse * XtX_inv[3, 3])
    t = b_int / se if se > 0 else 0
    p = 2 * (1 - stats.t.cdf(abs(t), df=df))
    ci_lo = b_int - stats.t.ppf(0.975, df=df) * se
    ci_hi = b_int + stats.t.ppf(0.975, df=df) * se
    return {'B': float(b_int), 'SE': float(se), 't': float(t), 'p': float(p),
            'ci': (float(ci_lo), float(ci_hi)),
            'delta_r2': float(delta_r2)}


def moderation_table() -> pd.DataFrame:
    """Build Table 8 — moderation effect tests."""
    demo = get_effective_subjects()
    mc = load_moral_cognition()
    me = load_moral_emotion()
    bi = load_behavioral_intention()
    eng = load_engagement()

    # Per-subject change scores
    mc_d = mc[['受试者编号', '分组']].copy()
    mc_d['mc_change'] = mc['T1_总分(0-100)'] - mc['T0_总分(0-100)']
    me_d = me[['受试者编号']].copy()
    me_d['me_change'] = me['T1_总均分'] - me['T0_总均分']
    bi_d = bi[['受试者编号']].copy()
    bi_d['bi_change'] = bi['T1_总均分'] - bi['T0_总均分']
    eng_subj = (eng.groupby('受试者编号')['交互频次(次)']
                    .mean().reset_index().rename(columns={'交互频次(次)': 'engagement'}))

    df = (mc_d.merge(me_d, on='受试者编号')
                 .merge(bi_d, on='受试者编号')
                 .merge(eng_subj, on='受试者编号')
                 .merge(demo[['受试者编号', '年龄', '性别',
                                '技术熟练度（1-5）', '虚拟偶像接触经历']],
                          on='受试者编号'))
    df['vi_dummy'] = (df['分组'] == '虚拟偶像组').astype(int)
    df['gender_f'] = (df['性别'] == '女').astype(int)
    df['prior_exp'] = df['虚拟偶像接触经历'].map({
        '无': 0, '偶尔': 1, '经常': 2, '频繁': 3
    }).fillna(0)

    rows = []
    tests = [
        ('Tech Proficiency × Treatment', 'Cognition', 'mc_change',
         'vi_dummy', '技术熟练度（1-5）'),
        ('Tech Proficiency × Treatment', 'Emotion', 'me_change',
         'vi_dummy', '技术熟练度（1-5）'),
        ('Prior Experience × Treatment', 'Cognition', 'mc_change',
         'vi_dummy', 'prior_exp'),
        ('Gender × Treatment', 'Behavior', 'bi_change',
         'vi_dummy', 'gender_f'),
        ('Age × Treatment', 'Engagement', 'engagement',
         'vi_dummy', '年龄'),
    ]

    for label, outcome, y_col, x_col, m_col in tests:
        sub = df[[y_col, x_col, m_col]].dropna()
        result = _hierarchical_regression(
            y=sub[y_col].values, x=sub[x_col].values, m=sub[m_col].values
        )
        sig_p = ('< 0.001' if result['p'] < 0.001 else
                 ('0.001' if result['p'] < 0.001 else f"{result['p']:.3f}"))
        rows.append({
            'Moderator': label,
            'Outcome': outcome,
            'B': f"{result['B']:.2f}",
            'SE': f"{result['SE']:.2f}",
            't': f"{result['t']:.2f}",
            'p': sig_p,
            '95% CI': f"[{result['ci'][0]:.2f}, {result['ci'][1]:.2f}]",
            'ΔR²': f"{result['delta_r2']:.3f}",
        })
    return pd.DataFrame(rows)


def simple_slopes() -> pd.DataFrame:
    """Simple-slope analysis at M±1SD of technology proficiency.
    Returns slope of VI treatment on outcome for high/low proficiency learners.
    """
    demo = get_effective_subjects()
    mc = load_moral_cognition()
    mc_d = mc[['受试者编号', '分组']].copy()
    mc_d['mc_change'] = mc['T1_总分(0-100)'] - mc['T0_总分(0-100)']
    df = mc_d.merge(demo[['受试者编号', '技术熟练度（1-5）']],
                     on='受试者编号')
    df['vi_dummy'] = (df['分组'] == '虚拟偶像组').astype(int)
    tp = df['技术熟练度（1-5）']
    rows = []
    for level_name, level in [('Low (M-1SD)', tp.mean() - tp.std(ddof=1)),
                                ('Mean', tp.mean()),
                                ('High (M+1SD)', tp.mean() + tp.std(ddof=1))]:
        # Regression: mc_change = b0 + b1·VI + b2·TP + b3·VI·(TP - level)
        x = df['vi_dummy'].values
        m_centered = (tp - level).values
        y = df['mc_change'].values
        X = np.column_stack([np.ones_like(y), x, m_centered, x * m_centered])
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        slope = coef[1]
        # t-test on slope
        n = len(y)
        ss_res = ((y - X @ coef) ** 2).sum()
        df_res = n - 4
        mse = ss_res / df_res if df_res > 0 else 0
        XtX_inv = np.linalg.pinv(X.T @ X)
        se = np.sqrt(mse * XtX_inv[1, 1]) if mse > 0 else 0
        t = slope / se if se > 0 else 0
        p = 2 * (1 - stats.t.cdf(abs(t), df=df_res)) if df_res > 0 else 1
        # standardized: β = b · SD(VI) / SD(Y)
        beta = slope * x.std(ddof=1) / y.std(ddof=1) if y.std(ddof=1) > 0 else 0
        rows.append({
            'Tech Proficiency Level': level_name,
            'β (VI effect on MC)': f"{beta:.2f}",
            't': f"{t:.2f}",
            'p': '< 0.001' if p < 0.001 else f"{p:.3f}",
        })
    return pd.DataFrame(rows)


def run() -> tuple:
    table8 = moderation_table()
    slopes = simple_slopes()
    table8.to_csv(TABLES_DIR / 'table8_moderation.csv',
                    index=False, encoding='utf-8-sig')
    slopes.to_csv(TABLES_DIR / 'simple_slopes.csv',
                    index=False, encoding='utf-8-sig')
    return table8, slopes


if __name__ == '__main__':
    t8, sl = run()
    print('=== Table 8: Moderation Effect Tests ===')
    print(t8.to_string(index=False))
    print('\n=== Simple-Slope Analysis (Tech Proficiency) ===')
    print(sl.to_string(index=False))
