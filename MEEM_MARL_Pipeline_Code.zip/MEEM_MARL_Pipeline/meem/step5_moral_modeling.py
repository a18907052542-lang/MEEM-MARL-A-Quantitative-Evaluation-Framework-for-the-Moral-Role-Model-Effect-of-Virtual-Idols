"""
MEEM-MARL Step 5 — Three-Stage Moral Modeling.

Bandura's social-learning theory operationalized as three sequential
latent transformations:

  z_a = f_Attention   (F_fused, Θ_VI)       # stage 1: observation
  z_r = f_Retention   (z_a, M_mem)           # stage 2: retention
  z_p = f_Reproduction(z_r, C)               # stage 3: reproduction

The Attention stage gates the fused multimodal feature with virtual-idol
parameters; Retention applies a recurrent memory layer; Reproduction
combines retention with content context to produce a moral-action latent.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import DIM_FUSED, DIM_MORAL_LATENT, SEED


torch.manual_seed(SEED)


class AttentionStage(nn.Module):
    """Stage 1 — Attention.

    z_a = σ(W_a · concat[F_fused, Θ_VI] + b_a)
    """
    def __init__(self, fused_dim: int = DIM_FUSED,
                  vi_param_dim: int = 16,
                  out_dim: int = DIM_MORAL_LATENT):
        super().__init__()
        self.fc1 = nn.Linear(fused_dim + vi_param_dim, 128)
        self.fc2 = nn.Linear(128, out_dim)
        # Learnable virtual-idol parameters (Θ_VI)
        self.theta_vi = nn.Parameter(torch.randn(1, vi_param_dim) * 0.1)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.1)

    def forward(self, F_fused: torch.Tensor) -> torch.Tensor:
        batch_size = F_fused.shape[0]
        theta = self.theta_vi.expand(batch_size, -1)
        x = torch.cat([F_fused, theta], dim=-1)
        x = self.dropout(self.relu(self.fc1(x)))
        return self.relu(self.fc2(x))


class RetentionStage(nn.Module):
    """Stage 2 — Retention.

    z_r = GRU(z_a, M_mem)
    Uses a single-step GRU to integrate observation into memory state.
    """
    def __init__(self, latent_dim: int = DIM_MORAL_LATENT):
        super().__init__()
        self.gru_cell = nn.GRUCell(latent_dim, latent_dim)
        # Initial memory M_mem
        self.M_mem_init = nn.Parameter(torch.zeros(1, latent_dim))

    def forward(self, z_a: torch.Tensor) -> torch.Tensor:
        batch_size = z_a.shape[0]
        M_mem = self.M_mem_init.expand(batch_size, -1).contiguous()
        z_r = self.gru_cell(z_a, M_mem)
        return z_r


class ReproductionStage(nn.Module):
    """Stage 3 — Reproduction.

    z_p = W_p · concat[z_r, C] + b_p
    The content context C represents curriculum/learning material features.
    """
    def __init__(self, latent_dim: int = DIM_MORAL_LATENT,
                  content_dim: int = 32):
        super().__init__()
        self.content_emb = nn.Embedding(12, content_dim)  # 12 content items (4 wk × 3 sessions)
        self.fc1 = nn.Linear(latent_dim + content_dim, 128)
        self.fc2 = nn.Linear(128, latent_dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.1)

    def forward(self, z_r: torch.Tensor, content_id: int = 0) -> torch.Tensor:
        batch_size = z_r.shape[0]
        # Content context — default to first item if not specified
        c_ids = torch.zeros(batch_size, dtype=torch.long)
        if content_id > 0:
            c_ids = c_ids + content_id
        C = self.content_emb(c_ids)
        x = torch.cat([z_r, C], dim=-1)
        x = self.dropout(self.relu(self.fc1(x)))
        return self.relu(self.fc2(x))


class ThreeStageMoralModel(nn.Module):
    """Composite three-stage moral modeling module."""
    def __init__(self):
        super().__init__()
        self.attention   = AttentionStage()
        self.retention   = RetentionStage()
        self.reproduction = ReproductionStage()

    def forward(self, F_fused: torch.Tensor,
                  content_id: int = 0) -> dict:
        z_a = self.attention(F_fused)
        z_r = self.retention(z_a)
        z_p = self.reproduction(z_r, content_id)
        return {'z_a': z_a, 'z_r': z_r, 'z_p': z_p}


def run(fused_results: dict) -> tuple:
    """Apply three-stage moral modeling to all subjects' fused features."""
    model = ThreeStageMoralModel()
    moral_latents = {}
    with torch.no_grad():
        for sid, data in fused_results.items():
            F_fused = data['fused']
            latents = model(F_fused, content_id=0)
            moral_latents[sid] = latents
    print(f'  [Step 5] Three-stage moral modeling complete: {len(moral_latents)} subjects')
    return moral_latents, model


if __name__ == '__main__':
    from meem.step1_preprocessing import run as step1
    from meem.step2_feature_extraction import run as step2
    from meem.step3_attention_fusion import run as step3
    feats = step1()
    encoded, _ = step2(feats)
    fused, _, _ = step3(encoded)
    latents, _ = run(fused)
    sid = next(iter(latents))
    print(f'\n=== Moral latents for subject {sid} ===')
    for stage, z in latents[sid].items():
        print(f'  {stage}: shape={tuple(z.shape)}, norm={z.norm().item():.3f}')
