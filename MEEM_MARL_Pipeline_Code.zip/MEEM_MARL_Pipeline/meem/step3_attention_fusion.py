"""
MEEM-MARL Step 3 — Attention-Weighted Late Fusion.

Implements:
  α_m = softmax(w_a · F_m + b_a)
  F_fused = Σ_m α_m · F_m

where F_m are the per-modality feature embeddings from Step 2 and α_m are
data-dependent attention weights normalized via softmax across modalities.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from config import (DIM_EYE, DIM_FACE, DIM_VOICE, DIM_PHYS, DIM_LOG,
                     DIM_FUSED, ATT_HIDDEN, SEED)


torch.manual_seed(SEED)


class AttentionFusion(nn.Module):
    """Attention-weighted late fusion across five modalities.

    Each modality is first projected to a common feature dimension `DIM_FUSED`,
    then a scoring head computes scalar attention weights α_m ∈ [0,1] which
    sum to 1 across modalities (softmax). The fused representation is the
    convex combination of projected modality features.
    """
    def __init__(self, modality_dims: dict = None, fused_dim: int = DIM_FUSED,
                  att_hidden: int = ATT_HIDDEN):
        super().__init__()
        if modality_dims is None:
            modality_dims = {'eye': DIM_EYE, 'face': DIM_FACE,
                              'voice': DIM_VOICE, 'phys': DIM_PHYS,
                              'log': DIM_LOG}
        self.modality_names = list(modality_dims.keys())
        # Per-modality projection to common fused dimension
        self.projections = nn.ModuleDict({
            name: nn.Linear(dim, fused_dim)
            for name, dim in modality_dims.items()
        })
        # Attention scoring head: input fused_dim → scalar
        self.attention_w = nn.Linear(fused_dim, att_hidden)
        self.attention_v = nn.Linear(att_hidden, 1)
        self.relu = nn.ReLU()

    def forward(self, modality_features: dict) -> tuple:
        """Compute fused feature and per-modality attention weights.

        Args:
            modality_features: dict {modality_name: Tensor of shape (B, dim_m)}
        Returns:
            F_fused: Tensor (B, fused_dim) — the weighted sum
            alpha:   Tensor (B, n_modalities) — attention weights
        """
        # Project each modality to the common fused dimension
        projected = []
        for name in self.modality_names:
            f = modality_features[name]
            projected.append(self.relu(self.projections[name](f)))
        # Stack: (B, n_modalities, fused_dim)
        stacked = torch.stack(projected, dim=1)
        # Compute attention scores per modality
        scores = self.attention_v(torch.tanh(self.attention_w(stacked)))
        # Squeeze to (B, n_modalities)
        scores = scores.squeeze(-1)
        # Softmax across modalities
        alpha = F.softmax(scores, dim=1)
        # Weighted sum: (B, fused_dim)
        F_fused = (alpha.unsqueeze(-1) * stacked).sum(dim=1)
        return F_fused, alpha


def run(encoded_features: dict) -> tuple:
    """Apply attention-weighted fusion to all subjects' encoded features."""
    fusion = AttentionFusion()
    fused_results = {}
    all_alphas = []
    with torch.no_grad():
        for sid, feats in encoded_features.items():
            F_fused, alpha = fusion(feats)
            fused_results[sid] = {
                'fused': F_fused,
                'alpha': alpha,
            }
            all_alphas.append(alpha.squeeze().numpy())
    mean_alpha = np.mean(np.array(all_alphas), axis=0)
    modality_names = list(fusion.modality_names)
    print(f'  [Step 3] Attention fusion complete: {len(fused_results)} subjects')
    print(f'  Mean attention weights across modalities:')
    for name, w in zip(modality_names, mean_alpha):
        print(f'    α_{name}: {w:.3f}')
    return fused_results, fusion, mean_alpha


if __name__ == '__main__':
    from meem.step1_preprocessing import run as step1
    from meem.step2_feature_extraction import run as step2
    feats = step1()
    encoded, _ = step2(feats)
    fused, fusion, mean_alpha = run(encoded)
    sid = next(iter(fused))
    print(f'\n=== Fused output for subject {sid} ===')
    print(f'  F_fused shape: {tuple(fused[sid]["fused"].shape)}')
    print(f'  Attention weights: {fused[sid]["alpha"].squeeze().numpy().round(3)}')
