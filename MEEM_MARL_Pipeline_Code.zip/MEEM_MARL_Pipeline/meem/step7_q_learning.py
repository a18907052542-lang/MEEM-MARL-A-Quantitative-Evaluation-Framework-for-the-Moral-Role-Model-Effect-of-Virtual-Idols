"""
MEEM-MARL Step 7 — Reinforcement-Learning Policy Update (Q-learning).

Implements the Q-learning update rule from Algorithm 1 Step 7:

  R_t = w1·ΔŶ_MC + w2·ΔŶ_ME + w3·ΔŶ_BI − w4·CL_t
  s_t = [e_t, Eng_t, Pres_t, CL_t, P]
  a_t ∈ A_VI = {expression, tone, content, pacing}

  Q(s_t, a_t) ← Q(s_t, a_t) + η_Q · [R_t + γ·max_{a'}Q(s_{t+1}, a') − Q(s_t, a_t)]
  π*(s) = argmax_a Q(s, a)
"""
import numpy as np
import torch
from collections import defaultdict

from config import (N_ACTIONS, ACTION_SPACE, Q_LEARNING_RATE, Q_DISCOUNT_GAMMA,
                     REWARD_WEIGHTS, SEED)


np.random.seed(SEED)


class QLearningAgent:
    """Tabular Q-learning agent over discretized states."""

    def __init__(self, n_actions: int = N_ACTIONS,
                  learning_rate: float = Q_LEARNING_RATE,
                  discount: float = Q_DISCOUNT_GAMMA,
                  n_state_bins: int = 4):
        self.n_actions = n_actions
        self.learning_rate = learning_rate
        self.discount = discount
        self.n_bins = n_state_bins
        # Q-table: dict mapping state-tuple → np.ndarray of length n_actions
        self.Q = defaultdict(lambda: np.zeros(n_actions))

    def _discretize(self, state_vector: np.ndarray) -> tuple:
        """Discretize a continuous state vector into a tuple of bin indices."""
        # Use simple equal-width binning over [0, 1]
        state = np.clip(state_vector, 0, 1)
        bins = (state * (self.n_bins - 1)).astype(int)
        return tuple(bins.flatten())

    def select_action(self, state_vector: np.ndarray,
                       epsilon: float = 0.1) -> int:
        """ε-greedy action selection."""
        state = self._discretize(state_vector)
        if np.random.rand() < epsilon:
            return np.random.randint(self.n_actions)
        return int(np.argmax(self.Q[state]))

    def compute_reward(self, delta_mc: float, delta_me: float,
                        delta_bi: float, cl: float) -> float:
        """Compute reward R_t per the paper's formula."""
        w = REWARD_WEIGHTS
        return (w['mc'] * delta_mc + w['me'] * delta_me
                + w['bi'] * delta_bi + w['cl'] * cl)

    def update(self, state: np.ndarray, action: int, reward: float,
                next_state: np.ndarray, done: bool = False):
        """Apply the Q-learning update rule."""
        s = self._discretize(state)
        s_next = self._discretize(next_state)
        td_target = reward
        if not done:
            td_target += self.discount * np.max(self.Q[s_next])
        td_error = td_target - self.Q[s][action]
        self.Q[s][action] += self.learning_rate * td_error
        return td_error

    def get_policy(self, state_vector: np.ndarray) -> int:
        """Return the greedy action π*(s) = argmax_a Q(s, a)."""
        state = self._discretize(state_vector)
        return int(np.argmax(self.Q[state]))


def simulate_episodes(agent: QLearningAgent,
                       estimated: dict,
                       predictions: dict,
                       n_episodes: int = 100,
                       verbose: bool = False) -> tuple:
    """Simulate Q-learning episodes using the affective + outcome data from steps 4-6.

    Each "episode" picks a subject and runs T=12 interaction steps (sessions),
    accumulating reward and updating Q-values.
    """
    subject_ids = list(estimated.keys())
    n_subjects = len(subject_ids)
    episode_rewards = []
    td_errors_per_ep = []

    for ep in range(n_episodes):
        sid = subject_ids[np.random.randint(n_subjects)]
        est = estimated[sid]
        pred = predictions[sid]

        # Initial state: [valence, arousal, engagement, presence, cog_load]
        state = np.array([
            float(est['valence'].item()),
            float(est['arousal'].item()),
            float(est['engagement'].item()),
            float(est['presence'].item()),
            float(est['cognitive_load'].item()),
        ]) * 0.5 + 0.5  # rescale [-1,1] → [0,1] for valence/arousal

        episode_reward = 0.0
        episode_td = []
        # T = 12 sessions over 4 weeks
        for t in range(12):
            action = agent.select_action(state, epsilon=max(0.05, 0.5 - ep/200))
            # Reward signal from outcome predictions
            delta_mc = float(pred['y_mc'].item()) * (1 + 0.1 * np.sin(t))
            delta_me = float(pred['y_me'].item()) * (1 + 0.1 * np.cos(t))
            delta_bi = float(pred['y_bi'].item())
            cl = float(est['cognitive_load'].item())
            reward = agent.compute_reward(delta_mc, delta_me, delta_bi, cl)

            # Next state: small Gaussian perturbation
            next_state = np.clip(state + np.random.randn(5) * 0.05, 0, 1)
            done = (t == 11)
            td_err = agent.update(state, action, reward, next_state, done)
            episode_td.append(abs(td_err))
            episode_reward += reward
            state = next_state

        episode_rewards.append(episode_reward)
        td_errors_per_ep.append(np.mean(episode_td))

        if verbose and (ep + 1) % 20 == 0:
            avg_r = np.mean(episode_rewards[-20:])
            avg_td = np.mean(td_errors_per_ep[-20:])
            print(f'    Episode {ep+1}: avg reward={avg_r:.3f}, '
                   f'avg TD error={avg_td:.4f}')

    return episode_rewards, td_errors_per_ep


def run(estimated: dict, predictions: dict,
         n_episodes: int = 100) -> tuple:
    """Run Q-learning training across all subjects."""
    agent = QLearningAgent()
    rewards, td_errors = simulate_episodes(agent, estimated, predictions,
                                              n_episodes=n_episodes,
                                              verbose=True)
    # Extract optimal policy per subject
    policies = {}
    for sid, est in estimated.items():
        state = np.array([
            float(est['valence'].item()),
            float(est['arousal'].item()),
            float(est['engagement'].item()),
            float(est['presence'].item()),
            float(est['cognitive_load'].item()),
        ]) * 0.5 + 0.5
        a_star = agent.get_policy(state)
        policies[sid] = {'optimal_action': ACTION_SPACE[a_star],
                          'action_idx': a_star}
    print(f'  [Step 7] Q-learning complete: {n_episodes} episodes, '
           f'final avg reward = {np.mean(rewards[-10:]):.3f}')
    return agent, policies, rewards


if __name__ == '__main__':
    from meem.step1_preprocessing import run as step1
    from meem.step2_feature_extraction import run as step2
    from meem.step3_attention_fusion import run as step3
    from meem.step4_affective_estimator import run as step4
    from meem.step5_moral_modeling import run as step5
    from meem.step6_outcome_predictor import run as step6
    feats = step1()
    encoded, _ = step2(feats)
    fused, _, _ = step3(encoded)
    estimated, _ = step4(fused)
    moral, _ = step5(fused)
    preds, _ = step6(moral, estimated)
    agent, policies, rewards = run(estimated, preds, n_episodes=50)
    print(f'\n=== Final policy distribution ===')
    from collections import Counter
    pol_counts = Counter(p['optimal_action'] for p in policies.values())
    for action, count in pol_counts.items():
        print(f'  {action}: {count} subjects ({count/len(policies)*100:.1f}%)')
