"""
MEEM-MARL Step 8 — Adaptive Content Recommendation.

Implements:
  c* = argmax_{c ∈ C} U( c | P, s_t, π* )

The utility function combines learner profile features, current latent state,
and optimal policy to score each candidate content item in the curriculum.
"""
import numpy as np
import torch
from collections import defaultdict

from config import N_CONTENT_ITEMS, ACTION_SPACE, SEED


np.random.seed(SEED)


# Content library: 12 items mapped to (week, session, theme)
CONTENT_LIBRARY = [
    {'id': 0,  'week': 1, 'session': 1, 'theme': 'Responsibility (Healthcare)',
     'cognitive_load': 0.6, 'social_presence': 0.7, 'emotional_intensity': 0.8},
    {'id': 1,  'week': 1, 'session': 2, 'theme': 'Responsibility (Border Guard)',
     'cognitive_load': 0.5, 'social_presence': 0.8, 'emotional_intensity': 0.9},
    {'id': 2,  'week': 1, 'session': 3, 'theme': 'Responsibility (Everyday)',
     'cognitive_load': 0.4, 'social_presence': 0.6, 'emotional_intensity': 0.5},
    {'id': 3,  'week': 2, 'session': 1, 'theme': 'Integrity (Courier)',
     'cognitive_load': 0.5, 'social_presence': 0.6, 'emotional_intensity': 0.6},
    {'id': 4,  'week': 2, 'session': 2, 'theme': 'Integrity (Academic)',
     'cognitive_load': 0.7, 'social_presence': 0.5, 'emotional_intensity': 0.5},
    {'id': 5,  'week': 2, 'session': 3, 'theme': 'Integrity (Business)',
     'cognitive_load': 0.6, 'social_presence': 0.6, 'emotional_intensity': 0.5},
    {'id': 6,  'week': 3, 'session': 1, 'theme': 'Kindness (Subway)',
     'cognitive_load': 0.4, 'social_presence': 0.7, 'emotional_intensity': 0.8},
    {'id': 7,  'week': 3, 'session': 2, 'theme': 'Kindness (Teaching)',
     'cognitive_load': 0.5, 'social_presence': 0.8, 'emotional_intensity': 0.7},
    {'id': 8,  'week': 3, 'session': 3, 'theme': 'Kindness (Cooperation)',
     'cognitive_load': 0.6, 'social_presence': 0.9, 'emotional_intensity': 0.6},
    {'id': 9,  'week': 4, 'session': 1, 'theme': 'Self-Discipline (Music)',
     'cognitive_load': 0.7, 'social_presence': 0.5, 'emotional_intensity': 0.6},
    {'id': 10, 'week': 4, 'session': 2, 'theme': 'Self-Discipline (Science)',
     'cognitive_load': 0.8, 'social_presence': 0.5, 'emotional_intensity': 0.7},
    {'id': 11, 'week': 4, 'session': 3, 'theme': 'Self-Discipline (Freedom)',
     'cognitive_load': 0.6, 'social_presence': 0.6, 'emotional_intensity': 0.8},
]


class UtilityRecommender:
    """Utility-based content recommender computing U(c | P, s, π*)."""

    def __init__(self, content_library: list = None):
        if content_library is None:
            content_library = CONTENT_LIBRARY
        self.library = content_library

    def compute_utility(self, content: dict, learner_profile: dict,
                          state: np.ndarray, action: str) -> float:
        """U = w1·content_match + w2·state_alignment + w3·policy_consistency."""
        # Content-profile match: prefer themes that pair with low prior knowledge
        prior_k = learner_profile.get('prior_knowledge', 50) / 100
        tech_skill = learner_profile.get('tech_proficiency', 3) / 5
        # Items with higher cognitive load benefit from higher prior knowledge
        content_match = 1.0 - abs(content['cognitive_load'] - prior_k)
        # State alignment: prefer items whose emotional intensity matches arousal
        arousal = (state[1] - 0.5) * 2  # rescale to [-1, 1]
        state_alignment = 1.0 - abs(content['emotional_intensity']
                                      - (arousal + 1) / 2)
        # Policy consistency: certain themes benefit from certain actions
        policy_consistency = 0.5
        if action == 'expression' and content['emotional_intensity'] > 0.7:
            policy_consistency = 0.9
        elif action == 'tone' and content['social_presence'] > 0.7:
            policy_consistency = 0.85
        elif action == 'content' and content['cognitive_load'] < 0.5:
            policy_consistency = 0.8
        elif action == 'pacing' and tech_skill < 0.5:
            policy_consistency = 0.85

        w1, w2, w3 = 0.4, 0.3, 0.3
        return w1 * content_match + w2 * state_alignment + w3 * policy_consistency

    def recommend(self, learner_profile: dict, state: np.ndarray,
                    action: str, top_k: int = 3) -> list:
        """Return top-K content items ranked by utility."""
        scored = []
        for c in self.library:
            u = self.compute_utility(c, learner_profile, state, action)
            scored.append((u, c))
        scored.sort(key=lambda x: -x[0])
        return scored[:top_k]


def run(estimated: dict, policies: dict, demo_df) -> dict:
    """Generate content recommendations for all subjects."""
    recommender = UtilityRecommender()
    recommendations = {}

    profile_map = demo_df.set_index('受试者编号')[
        ['先验道德知识基线分（0-100）', '技术熟练度（1-5）']
    ].to_dict('index')

    for sid, est in estimated.items():
        profile_raw = profile_map.get(sid, {'先验道德知识基线分（0-100）': 50,
                                              '技术熟练度（1-5）': 3})
        profile = {
            'prior_knowledge': profile_raw['先验道德知识基线分（0-100）'],
            'tech_proficiency': profile_raw['技术熟练度（1-5）'],
        }
        state = np.array([
            float(est['valence'].item()),
            float(est['arousal'].item()),
            float(est['engagement'].item()),
            float(est['presence'].item()),
            float(est['cognitive_load'].item()),
        ]) * 0.5 + 0.5
        action = policies[sid]['optimal_action']
        top_k = recommender.recommend(profile, state, action, top_k=3)
        recommendations[sid] = {
            'optimal_action': action,
            'top_3_content': [(u, c['id'], c['theme']) for u, c in top_k],
            'best_content_id': top_k[0][1]['id'],
            'best_content_theme': top_k[0][1]['theme'],
        }
    print(f'  [Step 8] Content recommendation complete: {len(recommendations)} subjects')

    # Aggregate content selection distribution
    from collections import Counter
    theme_counts = Counter(r['best_content_theme'] for r in recommendations.values())
    print(f'  Top recommended themes:')
    for theme, count in theme_counts.most_common(5):
        print(f'    {theme}: {count} subjects')

    return recommendations


if __name__ == '__main__':
    from utils.data_loader import get_effective_subjects
    from meem.step1_preprocessing import run as step1
    from meem.step2_feature_extraction import run as step2
    from meem.step3_attention_fusion import run as step3
    from meem.step4_affective_estimator import run as step4
    from meem.step5_moral_modeling import run as step5
    from meem.step6_outcome_predictor import run as step6
    from meem.step7_q_learning import run as step7
    feats = step1()
    encoded, _ = step2(feats)
    fused, _, _ = step3(encoded)
    estimated, _ = step4(fused)
    moral, _ = step5(fused)
    preds, _ = step6(moral, estimated)
    agent, policies, rewards = step7(estimated, preds, n_episodes=50)
    demo = get_effective_subjects()
    recs = run(estimated, policies, demo)
    sid = next(iter(recs))
    print(f'\n=== Recommendation for subject {sid} ===')
    print(f'  Optimal action: {recs[sid]["optimal_action"]}')
    print(f'  Top-3 content (utility, id, theme):')
    for u, cid, theme in recs[sid]['top_3_content']:
        print(f'    {u:.3f}  [{cid}] {theme}')
