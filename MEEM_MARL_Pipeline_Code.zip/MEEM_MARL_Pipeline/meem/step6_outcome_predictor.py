"""
MEEM-MARL Step 6 — Learning-Outcome Prediction.

Implements the three sigmoid heads from Algorithm 1 Step 6:
  Ŷ_MC = σ( W_mc · [z_p ; e_t ; Eng_t] + b_mc )
  Ŷ_ME = σ( W_me · [z_p ; e_t ; Pres_t] + b_me )
  Ŷ_BI = σ( W_bi · [z_p ; e_t ; Ŷ_ME] + b_bi )

Each output Ŷ ∈ [0, 1] is later rescaled to the measurement scale of the
corresponding outcome variable.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import DIM_MORAL_LATENT, HIDDEN_LSTM, SEED


torch.manual_seed(SEED)


class OutcomePredictor(nn.Module):
    """Three sigmoid heads producing MC/ME/BI predictions."""
    def __init__(self,
                 latent_dim: int = DIM_MORAL_LATENT,
                 affect_dim: int = HIDDEN_LSTM,
                 scalar_dim: int = 1):
        super().__init__()
        # MC head: concat[z_p, e_t, Eng]
        mc_input = latent_dim + affect_dim + scalar_dim
        self.W_mc = nn.Linear(mc_input, 1)
        # ME head: concat[z_p, e_t, Pres]
        me_input = latent_dim + affect_dim + scalar_dim
        self.W_me = nn.Linear(me_input, 1)
        # BI head: concat[z_p, e_t, Ŷ_ME]
        bi_input = latent_dim + affect_dim + scalar_dim
        self.W_bi = nn.Linear(bi_input, 1)

    def forward(self, z_p: torch.Tensor, e_t: torch.Tensor,
                  Eng_t: torch.Tensor, Pres_t: torch.Tensor) -> dict:
        # Predict MC
        y_mc = torch.sigmoid(self.W_mc(
            torch.cat([z_p, e_t, Eng_t], dim=-1)))
        # Predict ME
        y_me = torch.sigmoid(self.W_me(
            torch.cat([z_p, e_t, Pres_t], dim=-1)))
        # Predict BI (depends on ME)
        y_bi = torch.sigmoid(self.W_bi(
            torch.cat([z_p, e_t, y_me], dim=-1)))
        return {'y_mc': y_mc, 'y_me': y_me, 'y_bi': y_bi}


def composite_loss(predictions: dict, targets: dict,
                    model_params,
                    lambda_aff: float = 1.0,
                    lambda_moral: float = 1.0,
                    lambda_reg: float = 1e-4) -> torch.Tensor:
    """Composite loss function — Eq. 11 in the paper.

      L_total = λ_aff · L_aff + λ_moral · L_moral + λ_reg · ||θ||²

    L_aff is cross-entropy over emotion classes; L_moral is MSE on outcome
    predictions; the L2 norm regularizes all parameters.
    """
    loss_aff = F.cross_entropy(predictions.get('emotion_logits',
                                                 torch.zeros(1, 7)),
                                 targets.get('emotion_class',
                                              torch.zeros(1, dtype=torch.long)))
    pred_outcomes = torch.cat([predictions['y_mc'], predictions['y_me'],
                                predictions['y_bi']], dim=-1)
    target_outcomes = torch.cat([targets.get('y_mc', torch.zeros_like(predictions['y_mc'])),
                                   targets.get('y_me', torch.zeros_like(predictions['y_me'])),
                                   targets.get('y_bi', torch.zeros_like(predictions['y_bi']))], dim=-1)
    loss_moral = F.mse_loss(pred_outcomes, target_outcomes)
    l2 = sum((p ** 2).sum() for p in model_params)
    return lambda_aff * loss_aff + lambda_moral * loss_moral + lambda_reg * l2


def run(moral_latents: dict, estimated: dict) -> tuple:
    """Apply outcome predictors to all subjects."""
    predictor = OutcomePredictor()
    predictions = {}
    with torch.no_grad():
        for sid, latents in moral_latents.items():
            z_p = latents['z_p']
            est = estimated[sid]
            preds = predictor(z_p=z_p, e_t=est['affect_embed'],
                                 Eng_t=est['engagement'],
                                 Pres_t=est['presence'])
            predictions[sid] = preds
    print(f'  [Step 6] Outcome prediction complete: {len(predictions)} subjects')
    return predictions, predictor


if __name__ == '__main__':
    from meem.step1_preprocessing import run as step1
    from meem.step2_feature_extraction import run as step2
    from meem.step3_attention_fusion import run as step3
    from meem.step4_affective_estimator import run as step4
    from meem.step5_moral_modeling import run as step5
    feats = step1()
    encoded, _ = step2(feats)
    fused, _, _ = step3(encoded)
    estimated, _ = step4(fused)
    moral, _ = step5(fused)
    preds, _ = run(moral, estimated)
    sid = next(iter(preds))
    print(f'\n=== Outcome predictions for subject {sid} ===')
    for k, v in preds[sid].items():
        print(f'  {k}: {v.item():.4f}')
