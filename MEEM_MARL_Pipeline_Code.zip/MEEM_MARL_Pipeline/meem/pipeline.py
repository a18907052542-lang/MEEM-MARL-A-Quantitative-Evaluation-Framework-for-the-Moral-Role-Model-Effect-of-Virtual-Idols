"""
MEEM-MARL End-to-End Pipeline Orchestration.

Runs Algorithm 1 sequentially from Step 1 (preprocessing) through Step 9
(effect quantification) using the empirical data and the trained-in-place
deep learning components.
"""
import time
import numpy as np
import pandas as pd

from meem.step1_preprocessing import run as step1_run
from meem.step2_feature_extraction import run as step2_run
from meem.step3_attention_fusion import run as step3_run
from meem.step4_affective_estimator import run as step4_run
from meem.step5_moral_modeling import run as step5_run
from meem.step6_outcome_predictor import run as step6_run
from meem.step7_q_learning import run as step7_run
from meem.step8_recommender import run as step8_run
from meem.step9_effect_quantification import run as step9_run
from utils.data_loader import get_effective_subjects
from config import ACTION_SPACE, TABLES_DIR


def run_full_pipeline(n_rl_episodes: int = 100, verbose: bool = True) -> dict:
    """Execute the entire 9-step MEEM-MARL pipeline end-to-end.

    Returns a dict containing all intermediate outputs for downstream analysis
    or inspection.
    """
    t_start = time.time()
    if verbose:
        print('=' * 65)
        print('  MEEM-MARL PIPELINE — Algorithm 1 (Full End-to-End)')
        print('=' * 65)

    # Step 1: Preprocessing
    t = time.time()
    if verbose:
        print('\n[Step 1] Preprocessing multimodal signals...')
    features = step1_run()
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 2: Feature extraction
    t = time.time()
    if verbose:
        print('\n[Step 2] Per-modality feature extraction...')
    encoded, encoders = step2_run(features)
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 3: Attention-weighted late fusion
    t = time.time()
    if verbose:
        print('\n[Step 3] Attention-weighted late fusion...')
    fused, fusion_model, mean_alpha = step3_run(encoded)
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 4: Latent state estimation
    t = time.time()
    if verbose:
        print('\n[Step 4] Latent affective-state estimation (CNN-LSTM)...')
    estimated, estimator = step4_run(fused)
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 5: Three-stage moral modeling
    t = time.time()
    if verbose:
        print('\n[Step 5] Three-stage moral modeling (Attention → Retention → Reproduction)...')
    moral_latents, moral_model = step5_run(fused)
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 6: Outcome prediction
    t = time.time()
    if verbose:
        print('\n[Step 6] Learning-outcome prediction (MC/ME/BI)...')
    predictions, predictor = step6_run(moral_latents, estimated)
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 7: Q-learning policy update
    t = time.time()
    if verbose:
        print(f'\n[Step 7] Q-learning policy update ({n_rl_episodes} episodes)...')
    agent, policies, rl_rewards = step7_run(estimated, predictions,
                                              n_episodes=n_rl_episodes)
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 8: Adaptive content recommendation
    t = time.time()
    if verbose:
        print('\n[Step 8] Adaptive content recommendation...')
    demo = get_effective_subjects()
    recommendations = step8_run(estimated, policies, demo)
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Step 9: Effect quantification
    t = time.time()
    if verbose:
        print('\n[Step 9] Offline effect quantification (Cohen\'s d, retention, SEM)...')
    effect_results = step9_run()
    if verbose:
        print(f'  → completed in {time.time()-t:.1f}s')

    # Save pipeline diagnostic reports
    _save_pipeline_diagnostics(mean_alpha, predictions, policies, rl_rewards,
                                 recommendations)

    elapsed = time.time() - t_start
    if verbose:
        print('\n' + '=' * 65)
        print(f'  PIPELINE COMPLETE — total time: {elapsed:.1f}s')
        print('=' * 65)

    return {
        'features': features,
        'encoded': encoded,
        'fused': fused,
        'estimated': estimated,
        'moral_latents': moral_latents,
        'predictions': predictions,
        'policies': policies,
        'recommendations': recommendations,
        'effect_results': effect_results,
        'mean_alpha': mean_alpha,
        'rl_rewards': rl_rewards,
    }


def _save_pipeline_diagnostics(mean_alpha, predictions, policies,
                                  rl_rewards, recommendations):
    """Save pipeline diagnostic reports to results/tables/."""
    # Attention weight distribution
    modalities = ['eye', 'face', 'voice', 'phys', 'log']
    att_df = pd.DataFrame({
        'Modality': modalities,
        'Attention Weight α_m': [f"{a:.4f}" for a in mean_alpha],
        'Percentage': [f"{a*100:.2f}%" for a in mean_alpha],
    })
    att_df.to_csv(TABLES_DIR / 'pipeline_attention_weights.csv',
                    index=False, encoding='utf-8-sig')

    # Policy distribution
    from collections import Counter
    pol_counts = Counter(p['optimal_action'] for p in policies.values())
    total = len(policies)
    pol_df = pd.DataFrame([
        {'Action': a,
         'N Subjects': pol_counts.get(a, 0),
         'Percentage': f"{pol_counts.get(a, 0)/total*100:.1f}%"}
        for a in ACTION_SPACE
    ])
    pol_df.to_csv(TABLES_DIR / 'pipeline_policy_distribution.csv',
                    index=False, encoding='utf-8-sig')

    # Outcome prediction summary
    y_mc_vals = [float(p['y_mc'].item()) for p in predictions.values()]
    y_me_vals = [float(p['y_me'].item()) for p in predictions.values()]
    y_bi_vals = [float(p['y_bi'].item()) for p in predictions.values()]
    pred_df = pd.DataFrame({
        'Outcome': ['Moral Cognition Ŷ_MC',
                     'Moral Emotion Ŷ_ME',
                     'Behavioral Intention Ŷ_BI'],
        'Mean (across subjects)': [f"{np.mean(y_mc_vals):.4f}",
                                      f"{np.mean(y_me_vals):.4f}",
                                      f"{np.mean(y_bi_vals):.4f}"],
        'SD': [f"{np.std(y_mc_vals):.4f}",
                f"{np.std(y_me_vals):.4f}",
                f"{np.std(y_bi_vals):.4f}"],
    })
    pred_df.to_csv(TABLES_DIR / 'pipeline_outcome_predictions.csv',
                    index=False, encoding='utf-8-sig')

    # RL training curve
    rl_df = pd.DataFrame({
        'Episode': range(1, len(rl_rewards) + 1),
        'Reward': rl_rewards,
        'Cumulative Mean': np.cumsum(rl_rewards) / np.arange(1, len(rl_rewards) + 1),
    })
    rl_df.to_csv(TABLES_DIR / 'pipeline_rl_training_curve.csv',
                  index=False, encoding='utf-8-sig')

    # Content recommendation distribution
    from collections import Counter
    theme_counts = Counter(r['best_content_theme']
                              for r in recommendations.values())
    rec_df = pd.DataFrame([
        {'Theme': t, 'N Recommended': c,
         'Percentage': f"{c/total*100:.1f}%"}
        for t, c in theme_counts.most_common()
    ])
    rec_df.to_csv(TABLES_DIR / 'pipeline_content_recommendations.csv',
                    index=False, encoding='utf-8-sig')


if __name__ == '__main__':
    results = run_full_pipeline(n_rl_episodes=100, verbose=True)
    print('\n=== Pipeline Summary ===')
    print(f'  Subjects processed: {len(results["features"])}')
    print(f'  Mean attention weights across modalities: {results["mean_alpha"].round(3)}')
    print(f'  Final RL reward (last 10 episodes): {np.mean(results["rl_rewards"][-10:]):.3f}')
