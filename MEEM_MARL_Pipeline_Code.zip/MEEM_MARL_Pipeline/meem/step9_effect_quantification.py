"""
MEEM-MARL Step 9 — Effect Quantification (offline).

Implements:
  d      = ( Ȳ_VI − Ȳ_ctrl ) / S_p              # Cohen's d effect size
  Ret(t) = Ŷ(t) / Ŷ(T_0)                        # retention curve
  {β_ij} ← SEM path-coefficient estimation       # via analysis.sem

This step ties the MEEM-MARL deep-learning pipeline back to the empirical
data analysis pipeline.
"""
import pandas as pd
import numpy as np

from utils.data_loader import (load_moral_cognition, load_moral_emotion,
                                load_behavioral_intention,
                                get_effective_subjects)
from utils.stats_utils import cohen_d
from config import GROUP_ORDER_CN, GROUP_ORDER_EN, TABLES_DIR


def effect_size_summary() -> pd.DataFrame:
    """Compute Cohen's d for each outcome × group vs Control."""
    mc = load_moral_cognition()
    me = load_moral_emotion()
    bi = load_behavioral_intention()

    measures = [
        ('Moral Cognition', mc, 'T0_总分(0-100)', 'T1_总分(0-100)'),
        ('Moral Emotion',   me, 'T0_总均分', 'T1_总均分'),
        ('Behavioral Intention', bi, 'T0_总均分', 'T1_总均分'),
    ]

    rows = []
    for label, df, pre_col, post_col in measures:
        ctrl = df[df['分组'] == '控制组']
        ctrl_change = ctrl[post_col].values - ctrl[pre_col].values
        for g_cn, g_en in zip(GROUP_ORDER_CN, GROUP_ORDER_EN):
            sub = df[df['分组'] == g_cn]
            change = sub[post_col].values - sub[pre_col].values
            if g_en == 'Control':
                d_val = change.mean() / change.std(ddof=1) if change.std(ddof=1) > 0 else 0
                rows.append({
                    'Outcome': label, 'Group': g_en,
                    "Cohen's d": f"{d_val:.2f} (within)",
                    'Effect Magnitude': _interpret_d(d_val),
                })
            else:
                d_val = cohen_d(change, ctrl_change)
                rows.append({
                    'Outcome': label, 'Group': g_en,
                    "Cohen's d": f"{d_val:.2f}",
                    'Effect Magnitude': _interpret_d(d_val),
                })
    return pd.DataFrame(rows)


def _interpret_d(d: float) -> str:
    """Cohen's interpretation thresholds."""
    if abs(d) >= 0.8: return 'Large'
    if abs(d) >= 0.5: return 'Medium'
    if abs(d) >= 0.2: return 'Small'
    return 'Negligible'


def retention_curve_summary() -> pd.DataFrame:
    """Retention curves at 4 and 8 weeks per group, per outcome.
    Ret(t) = (Ŷ(t) - baseline) / (Ŷ(T_post) - baseline) × 100%
    """
    mc = load_moral_cognition()
    rows = []
    for g_cn, g_en in zip(GROUP_ORDER_CN, GROUP_ORDER_EN):
        sub = mc[mc['分组'] == g_cn]
        baseline = sub['T0_总分(0-100)'].mean()
        post = sub['T1_总分(0-100)'].mean()
        f4 = sub['T2_4wk_总分(0-100)'].mean()
        f8 = sub['T2_8wk_总分(0-100)'].mean()
        gain_post = post - baseline
        rows.append({
            'Group': g_en,
            'Baseline': f"{baseline:.1f}",
            'Post-Test': f"{post:.1f}",
            '4-Wk Follow-up': f"{f4:.1f}",
            '8-Wk Follow-up': f"{f8:.1f}",
            'Ret 4wk (%)': f"{(f4 - baseline) / gain_post * 100:.1f}",
            'Ret 8wk (%)': f"{(f8 - baseline) / gain_post * 100:.1f}",
        })
    return pd.DataFrame(rows)


def aggregate_effect_quantification() -> dict:
    """Aggregate Step 9 effect quantification — Cohen's d + retention."""
    cohens_d = effect_size_summary()
    retention = retention_curve_summary()

    # Save
    cohens_d.to_csv(TABLES_DIR / 'effect_quantification_cohens_d.csv',
                     index=False, encoding='utf-8-sig')
    retention.to_csv(TABLES_DIR / 'effect_quantification_retention.csv',
                      index=False, encoding='utf-8-sig')

    return {'cohens_d': cohens_d, 'retention': retention}


def run() -> dict:
    """Run Step 9 — effect quantification."""
    results = aggregate_effect_quantification()
    print(f'  [Step 9] Effect quantification complete')
    print(f'  Cohen\'s d summary:')
    print(f'    Moral Cognition: VI = ' +
            results['cohens_d'].query('Outcome == "Moral Cognition"')
            .query('Group == "Virtual Idol"')["Cohen's d"].values[0])
    print(f'  Retention summary (Moral Cognition):')
    print(f'    8-Wk: ' + results['retention'].query('Group == "Virtual Idol"')['Ret 8wk (%)'].values[0] + '%')
    return results


if __name__ == '__main__':
    res = run()
    print(f'\n=== Cohen\'s d (effect size) ===')
    print(res['cohens_d'].to_string(index=False))
    print(f'\n=== Retention curves (moral cognition) ===')
    print(res['retention'].to_string(index=False))
