"""
MEEM-MARL Step 2 — Per-Modality Feature Extraction.

Implements the per-modality encoders from Algorithm 1 Step 2:
  F_eye   = 1D-CNN(W_eye  ; θ_1)   # fixation / saccade features
  F_face  = CNN-FACS(W_face ; θ_2) # 68-keypoint FACS action-unit features
  F_voice = Transformer(W_voice ; θ_3) # prosodic features
  F_phys  = LSTM([W_hrv, W_skin, W_eeg] ; θ_4)
  F_behav = MLP(W_log ; θ_5)        # interaction / clickstream features
"""
import torch
import torch.nn as nn
import numpy as np

from config import (DIM_EYE, DIM_FACE, DIM_VOICE, DIM_PHYS, DIM_LOG, SEED)


# Reproducibility
torch.manual_seed(SEED)


class EyeCNN(nn.Module):
    """1-D CNN encoder for eye-tracking features (fixation density, saccade)."""
    def __init__(self, input_dim: int = 5, out_dim: int = DIM_EYE):
        super().__init__()
        # Input is (batch, channels=1, sequence=input_dim)
        self.conv1 = nn.Conv1d(1, 16, kernel_size=2, padding=1)
        self.conv2 = nn.Conv1d(16, 32, kernel_size=2, padding=1)
        self.pool = nn.AdaptiveAvgPool1d(4)
        self.fc = nn.Linear(32 * 4, out_dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (B, 1, L)
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.pool(x)
        x = x.flatten(start_dim=1)
        return self.dropout(self.relu(self.fc(x)))


class FaceFACS(nn.Module):
    """CNN encoder for facial-action-unit / FACS features."""
    def __init__(self, input_dim: int = 8, out_dim: int = DIM_FACE):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool1d(4)
        self.fc = nn.Linear(64 * 4, out_dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.pool(x)
        x = x.flatten(start_dim=1)
        return self.dropout(self.relu(self.fc(x)))


class VoiceTransformer(nn.Module):
    """Transformer encoder for voice/prosodic features (synthesized from log timing)."""
    def __init__(self, input_dim: int = 4, out_dim: int = DIM_VOICE, n_heads: int = 4,
                  n_layers: int = 2, d_model: int = 64):
        super().__init__()
        self.proj = nn.Linear(input_dim, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, batch_first=True,
            dim_feedforward=128, dropout=0.1)
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.fc = nn.Linear(d_model, out_dim)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 2:
            x = x.unsqueeze(1)  # (B, seq=1, input_dim)
        x = self.proj(x)
        x = self.encoder(x)
        x = x.mean(dim=1)        # Aggregate over sequence
        return self.relu(self.fc(x))


class PhysLSTM(nn.Module):
    """LSTM encoder for physiological signals (HRV / SCL / EEG)."""
    def __init__(self, input_dim: int = 7, out_dim: int = DIM_PHYS, hidden_dim: int = 64):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True,
                              num_layers=2, dropout=0.1, bidirectional=True)
        self.fc = nn.Linear(hidden_dim * 2, out_dim)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 2:
            x = x.unsqueeze(1)
        out, _ = self.lstm(x)
        out = out.mean(dim=1)
        return self.relu(self.fc(out))


class LogMLP(nn.Module):
    """MLP for system interaction-log features."""
    def __init__(self, input_dim: int = 6, out_dim: int = DIM_LOG):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 64)
        self.fc2 = nn.Linear(64, out_dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 3:
            x = x.mean(dim=1)
        x = self.dropout(self.relu(self.fc1(x)))
        return self.relu(self.fc2(x))


def build_encoders() -> dict:
    """Construct the five per-modality encoders described in Algorithm 1 Step 2."""
    return {
        'eye':   EyeCNN(),
        'face':  FaceFACS(),
        'voice': VoiceTransformer(),
        'phys':  PhysLSTM(),
        'log':   LogMLP(),
    }


def extract_features_for_subject(features: dict, encoders: dict) -> dict:
    """Extract feature embeddings for all modalities of one subject.
    `features` is a dict like {'phys': ndarray, 'eye': ndarray, ...}
    Returns a dict {modality: torch.Tensor of shape (1, dim_modality)}
    """
    encoded = {}
    with torch.no_grad():
        # Eye (5 features)
        eye_arr = features.get('eye', np.zeros((1, 5)))
        x = torch.tensor(eye_arr.mean(axis=0, keepdims=True), dtype=torch.float32)
        # Ensure correct shape
        if x.shape[1] < 5:
            x = torch.cat([x, torch.zeros(1, 5 - x.shape[1])], dim=1)
        elif x.shape[1] > 5:
            x = x[:, :5]
        encoded['eye'] = encoders['eye'](x)

        # Face (8 features)
        face_arr = features.get('face', np.zeros((1, 8)))
        x = torch.tensor(face_arr.mean(axis=0, keepdims=True), dtype=torch.float32)
        if x.shape[1] < 8:
            x = torch.cat([x, torch.zeros(1, 8 - x.shape[1])], dim=1)
        elif x.shape[1] > 8:
            x = x[:, :8]
        encoded['face'] = encoders['face'](x)

        # Voice — derived from log features (4 timing-based proxies)
        log_arr = features.get('log', np.zeros((1, 6)))
        x = torch.tensor(log_arr.mean(axis=0, keepdims=True)[:, :4],
                          dtype=torch.float32)
        if x.shape[1] < 4:
            x = torch.cat([x, torch.zeros(1, 4 - x.shape[1])], dim=1)
        encoded['voice'] = encoders['voice'](x)

        # Phys (7 features)
        phys_arr = features.get('phys', np.zeros((1, 7)))
        x = torch.tensor(phys_arr.mean(axis=0, keepdims=True), dtype=torch.float32)
        if x.shape[1] < 7:
            x = torch.cat([x, torch.zeros(1, 7 - x.shape[1])], dim=1)
        elif x.shape[1] > 7:
            x = x[:, :7]
        encoded['phys'] = encoders['phys'](x)

        # Log
        x = torch.tensor(log_arr.mean(axis=0, keepdims=True), dtype=torch.float32)
        if x.shape[1] < 6:
            x = torch.cat([x, torch.zeros(1, 6 - x.shape[1])], dim=1)
        elif x.shape[1] > 6:
            x = x[:, :6]
        encoded['log'] = encoders['log'](x)
    return encoded


def run(all_features: dict) -> tuple:
    """Encode all subjects' features through their per-modality encoders."""
    encoders = build_encoders()
    all_encoded = {}
    for sid, feats in all_features.items():
        all_encoded[sid] = extract_features_for_subject(feats, encoders)
    print(f'  [Step 2] Feature extraction complete: {len(all_encoded)} subjects')
    return all_encoded, encoders


if __name__ == '__main__':
    from meem.step1_preprocessing import run as step1
    feats = step1()
    encoded, enc = run(feats)
    sid = next(iter(encoded))
    print(f'\n=== Encoded features for subject {sid} ===')
    for mod, t in encoded[sid].items():
        print(f'  {mod}: shape={tuple(t.shape)}, norm={t.norm().item():.3f}')
