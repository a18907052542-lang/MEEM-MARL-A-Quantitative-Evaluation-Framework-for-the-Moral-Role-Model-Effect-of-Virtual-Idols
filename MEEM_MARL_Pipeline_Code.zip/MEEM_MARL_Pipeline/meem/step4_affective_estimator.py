"""
MEEM-MARL Step 4 — Latent State Estimation.

Implements:
  e_t              ← CNN-LSTM(F_fused ; θ_aff)       # affective state
  [Eng_t, Pres_t]  ← MLP(F_fused ; θ_eps)             # engagement & presence
  CL_t             ← Reg(F_fused ; θ_cl)              # cognitive load

The affective head classifies 7 basic emotions (Ekman) and predicts continuous
valence and arousal.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import DIM_FUSED, N_EMOTIONS, HIDDEN_LSTM, SEED


torch.manual_seed(SEED)


class CNNLSTMAffective(nn.Module):
    """Hybrid CNN-LSTM head producing affective state estimates.

    Outputs:
      emotion_logits: (B, 7)            -- 7 basic emotions
      valence:         (B, 1)            -- continuous [-1, +1]
      arousal:         (B, 1)            -- continuous [-1, +1]
      affect_embed:    (B, hidden)       -- latent embedding e_t
    """
    def __init__(self, fused_dim: int = DIM_FUSED, hidden: int = HIDDEN_LSTM,
                  n_emotions: int = N_EMOTIONS):
        super().__init__()
        # CNN over the fused feature treated as a 1-D signal
        self.conv1 = nn.Conv1d(1, 16, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(16, 32, kernel_size=3, padding=1)
        self.pool = nn.MaxPool1d(kernel_size=2)
        cnn_out_len = (fused_dim // 2 // 2)
        # LSTM consuming the CNN output as a sequence
        self.lstm = nn.LSTM(32, hidden, batch_first=True,
                              num_layers=1, dropout=0.0)
        # Heads
        self.emotion_head = nn.Linear(hidden, n_emotions)
        self.valence_head = nn.Tanh()
        self.va_proj = nn.Linear(hidden, 2)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> dict:
        # x: (B, fused_dim) → (B, 1, fused_dim)
        if x.dim() == 2:
            x = x.unsqueeze(1)
        c = self.relu(self.conv1(x))
        c = self.pool(c)
        c = self.relu(self.conv2(c))
        c = self.pool(c)
        # (B, 32, L) → (B, L, 32) for LSTM
        c = c.transpose(1, 2)
        out, (h, _) = self.lstm(c)
        affect_embed = h.squeeze(0)
        emotion_logits = self.emotion_head(affect_embed)
        va = self.va_proj(affect_embed)
        valence = torch.tanh(va[:, 0:1])
        arousal = torch.tanh(va[:, 1:2])
        return {
            'emotion_logits': emotion_logits,
            'valence': valence,
            'arousal': arousal,
            'affect_embed': affect_embed,
        }


class EngagementPresenceMLP(nn.Module):
    """MLP head predicting [engagement, presence] from fused features."""
    def __init__(self, fused_dim: int = DIM_FUSED, out_dim: int = 2):
        super().__init__()
        self.fc1 = nn.Linear(fused_dim, 64)
        self.fc2 = nn.Linear(64, out_dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.dropout(self.relu(self.fc1(x)))
        return torch.sigmoid(self.fc2(x))  # in [0,1]


class CognitiveLoadReg(nn.Module):
    """Regression head predicting cognitive load CL_t in [0,1]."""
    def __init__(self, fused_dim: int = DIM_FUSED):
        super().__init__()
        self.fc1 = nn.Linear(fused_dim, 32)
        self.fc2 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.fc2(self.relu(self.fc1(x))))


class AffectiveStateEstimator(nn.Module):
    """Composite Step-4 module combining all three heads."""
    def __init__(self, fused_dim: int = DIM_FUSED):
        super().__init__()
        self.cnn_lstm = CNNLSTMAffective(fused_dim)
        self.eng_pres = EngagementPresenceMLP(fused_dim)
        self.cog_load = CognitiveLoadReg(fused_dim)

    def forward(self, F_fused: torch.Tensor) -> dict:
        aff = self.cnn_lstm(F_fused)
        eng_pres = self.eng_pres(F_fused)
        cl = self.cog_load(F_fused)
        return {
            'affect_embed': aff['affect_embed'],
            'emotion_logits': aff['emotion_logits'],
            'valence': aff['valence'],
            'arousal': aff['arousal'],
            'engagement': eng_pres[:, 0:1],
            'presence':   eng_pres[:, 1:2],
            'cognitive_load': cl,
        }


def run(fused_results: dict) -> tuple:
    """Apply affective state estimator to all subjects' fused features."""
    estimator = AffectiveStateEstimator()
    estimated = {}
    with torch.no_grad():
        for sid, data in fused_results.items():
            F_fused = data['fused']
            est = estimator(F_fused)
            estimated[sid] = est
    print(f'  [Step 4] Affective state estimation complete: {len(estimated)} subjects')
    return estimated, estimator


if __name__ == '__main__':
    from meem.step1_preprocessing import run as step1
    from meem.step2_feature_extraction import run as step2
    from meem.step3_attention_fusion import run as step3
    feats = step1()
    encoded, _ = step2(feats)
    fused, _, _ = step3(encoded)
    estimated, _ = run(fused)
    sid = next(iter(estimated))
    print(f'\n=== Affective state for subject {sid} ===')
    for k, v in estimated[sid].items():
        print(f'  {k}: shape={tuple(v.shape)}, value={v.squeeze().detach().numpy().round(3) if v.numel() < 10 else "(embedding)"}')
