"""
MEEM-MARL Step 1 — Preprocessing.

Implements the preprocessing pipeline described in Algorithm 1 Step 1 and §3.3
of the paper (Table 1):
  - Median filter (window=5) for outlier/noise removal
  - Z-score normalization (μ=0, σ=1)
  - Sliding window segmentation (size=2 s, overlap=50%)
  - PCA dimensionality reduction (retain 95% variance) — Eq. 7
  - SMOTE oversampling for class imbalance — Eq. 8
"""
import numpy as np
import pandas as pd
from scipy.signal import medfilt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from utils.data_loader import (load_physiological, load_eye_tracking,
                                load_facial, load_engagement)
from config import (MEDIAN_FILTER_WINDOW, SLIDING_WINDOW_SIZE,
                     SLIDING_WINDOW_OVERLAP, SEED)


def median_filter(x: np.ndarray, window: int = MEDIAN_FILTER_WINDOW) -> np.ndarray:
    """1-D median filter; window must be odd."""
    if window % 2 == 0:
        window += 1
    return medfilt(x.astype(float), kernel_size=window)


def zscore(x: np.ndarray) -> np.ndarray:
    """Z-score normalize: (x − μ) / σ."""
    x = np.asarray(x, dtype=float)
    mu = x.mean()
    sigma = x.std(ddof=1)
    if sigma == 0:
        return x - mu
    return (x - mu) / sigma


def sliding_window(x: np.ndarray, window_size: int, overlap: float = SLIDING_WINDOW_OVERLAP
                    ) -> np.ndarray:
    """Segment a 1-D signal into overlapping windows.
    Returns shape (n_windows, window_size).
    """
    x = np.asarray(x)
    step = max(1, int(window_size * (1 - overlap)))
    n_windows = max(0, (len(x) - window_size) // step + 1)
    if n_windows == 0:
        return x[np.newaxis, :window_size] if len(x) >= window_size else x[np.newaxis, :]
    return np.lib.stride_tricks.sliding_window_view(x, window_size)[::step]


def pca_reduce(X: np.ndarray, variance_threshold: float = 0.95) -> tuple:
    """Apply PCA retaining at least `variance_threshold` of explained variance.
    Implements Eq. 7: Y = XW
    """
    if X.shape[0] < 2:
        return X, None
    pca = PCA(n_components=variance_threshold, svd_solver='full')
    Y = pca.fit_transform(X)
    return Y, pca


def smote_oversample(X: np.ndarray, y: np.ndarray, k: int = 5) -> tuple:
    """SMOTE (Synthetic Minority Over-sampling Technique) — Eq. 8 in the paper.
    x_new = x_i + λ(x_zi − x_i), λ ∈ [0,1], z_i a k-NN of x_i.
    """
    try:
        from imblearn.over_sampling import SMOTE
        sm = SMOTE(k_neighbors=min(k, max(1, np.bincount(y).min() - 1)),
                    random_state=SEED)
        X_res, y_res = sm.fit_resample(X, y)
        return X_res, y_res
    except (ImportError, ValueError):
        return X, y


def preprocess_subject_signals(subject_id: str) -> dict:
    """Apply the full Step-1 preprocessing chain to a single subject's data.
    Returns a dict with one entry per modality containing windowed features.
    """
    phys = load_physiological()
    eye  = load_eye_tracking()
    face = load_facial()
    log  = load_engagement()

    out = {}
    # Per-session feature vectors are treated as individual observations.
    # within a session, we use the per-session vectors directly.

    for mod_name, df, cols in [
        ('phys', phys, ['HRV_RMSSD(ms)', 'HRV_SDNN(ms)', '皮肤电导_SCL(μS)',
                          'EEG_Alpha功率(μV²)', 'EEG_Beta功率(μV²)',
                          'EEG_Alpha/Beta比值', 'EEG_Theta功率(μV²)']),
        ('eye',  eye,  ['平均注视时长(ms)', '注视点数量', '平均扫视幅度(°)',
                          '平均瞳孔直径(mm)', '眨眼频率(次/分钟)']),
        ('face', face, ['高兴时长占比(%)', '中性时长占比(%)', '悲伤时长占比(%)',
                          'Valence效价(-1~+1)', 'Arousal唤醒(-1~+1)',
                          'AU01_内眉上扬', 'AU06_脸颊上提', 'AU12_嘴角上拉_微笑']),
        ('log',  log,  ['会话时长(分钟)', '交互频次(次)', '点击次数',
                          '滚动次数', '提问次数', '内容覆盖率(%)']),
    ]:
        sub = df[df['受试者编号'] == subject_id]
        if len(sub) == 0:
            out[mod_name] = np.zeros((1, len(cols)))
            continue

        signals = sub[cols].values.astype(float)
        # Median filter applied column-wise
        if signals.shape[0] >= MEDIAN_FILTER_WINDOW:
            for c in range(signals.shape[1]):
                signals[:, c] = median_filter(signals[:, c],
                                                MEDIAN_FILTER_WINDOW)
        # Z-score per column
        signals = StandardScaler().fit_transform(signals)
        out[mod_name] = signals  # shape (n_sessions, n_features)
    return out


def preprocess_all_subjects(verbose: bool = False) -> dict:
    """Run preprocessing on all 186 effective subjects.
    Returns a dict mapping subject_id → modality dict.
    """
    from utils.data_loader import get_effective_subjects
    demo = get_effective_subjects()
    all_features = {}
    for i, sid in enumerate(demo['受试者编号']):
        all_features[sid] = preprocess_subject_signals(sid)
        if verbose and (i + 1) % 30 == 0:
            print(f'  Preprocessed {i+1}/{len(demo)} subjects')
    return all_features


def run() -> dict:
    """Execute Step 1 — preprocess all subjects' signals."""
    features = preprocess_all_subjects(verbose=True)
    print(f'  [Step 1] Preprocessing complete: {len(features)} subjects')
    return features


if __name__ == '__main__':
    feats = run()
    # Show a sample for the first subject
    sid = next(iter(feats))
    print(f'\n=== Sample feature shapes for subject {sid} ===')
    for mod, arr in feats[sid].items():
        print(f'  {mod}: shape = {arr.shape}, mean={arr.mean():.3f}, std={arr.std():.3f}')
