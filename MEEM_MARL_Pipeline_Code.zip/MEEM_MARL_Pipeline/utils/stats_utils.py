"""
Statistical utilities shared across analysis modules.
All formulas trace back to standard equations cited in the paper:
- Cohen's d (Eq. 10)
- Cronbach's α (Eq. 2)
- partial η² (mixed-model effect size)
"""
import numpy as np
import pandas as pd
from scipy import stats
from itertools import combinations
from typing import Tuple


def cohen_d(x1: np.ndarray, x2: np.ndarray) -> float:
    """Cohen's d = (X̄₁ − X̄₂) / S_pooled   (Eq. 10 in paper).

    Uses pooled SD with (n₁-1) and (n₂-1) degrees of freedom.
    Returns a signed value (positive when mean(x1) > mean(x2)).
    """
    x1, x2 = np.asarray(x1, dtype=float), np.asarray(x2, dtype=float)
    n1, n2 = len(x1), len(x2)
    s1, s2 = x1.std(ddof=1), x2.std(ddof=1)
    pooled = np.sqrt(((n1 - 1) * s1**2 + (n2 - 1) * s2**2) / (n1 + n2 - 2))
    if pooled == 0:
        return 0.0
    return (x1.mean() - x2.mean()) / pooled


def cohen_d_within(pre: np.ndarray, post: np.ndarray) -> float:
    """Within-subject Cohen's d using SD of the difference scores."""
    pre, post = np.asarray(pre, dtype=float), np.asarray(post, dtype=float)
    diff = post - pre
    sd = diff.std(ddof=1)
    if sd == 0:
        return 0.0
    return diff.mean() / sd


def cronbach_alpha(items: np.ndarray) -> float:
    """Cronbach's α = (k / (k-1)) · (1 − Σσ²ᵢ / σ²_total)   (Eq. 2 in paper).

    items: ndarray of shape (n_subjects, k_items)
    """
    items = np.asarray(items, dtype=float)
    k = items.shape[1]
    item_var = items.var(axis=0, ddof=1).sum()
    total_var = items.sum(axis=1).var(ddof=1)
    if total_var == 0:
        return float('nan')
    return (k / (k - 1)) * (1 - item_var / total_var)


def partial_eta_squared(ss_effect: float, ss_error: float) -> float:
    """Partial η² = SS_effect / (SS_effect + SS_error)."""
    return ss_effect / (ss_effect + ss_error) if (ss_effect + ss_error) > 0 else 0.0


def oneway_anova_3groups(g1: np.ndarray, g2: np.ndarray, g3: np.ndarray
                         ) -> Tuple[float, float, float]:
    """One-way ANOVA across three groups. Returns (F, p, η²_p)."""
    f, p = stats.f_oneway(g1, g2, g3)
    means = [np.mean(g) for g in (g1, g2, g3)]
    ns = [len(g) for g in (g1, g2, g3)]
    grand_mean = sum(m * n for m, n in zip(means, ns)) / sum(ns)
    ss_between = sum(n * (m - grand_mean) ** 2 for m, n in zip(means, ns))
    ss_within = sum(((np.asarray(g) - m) ** 2).sum() for g, m in zip((g1, g2, g3), means))
    eta2_p = partial_eta_squared(ss_between, ss_within)
    return float(f), float(p), float(eta2_p)


def repeated_anova(pre: pd.Series, post: pd.Series, groups: pd.Series
                   ) -> dict:
    """Repeated-measures (mixed) ANOVA — group × time.

    Returns a dict with F and p for time, group, and time×group, plus partial η².
    Implements Eq. 9 in the paper: Y_ijk = μ + αᵢ + βⱼ + (αβ)ᵢⱼ + γₖ + εᵢⱼₖ
    where α is the group effect (between), β the time effect (within),
    and γₖ the random subject effect.
    """
    df = pd.DataFrame({'pre': pre, 'post': post, 'group': groups}).dropna()
    long = df.melt(id_vars='group', value_vars=['pre', 'post'],
                   var_name='time', value_name='y')
    long['time_code'] = long['time'].map({'pre': 0, 'post': 1})

    # Sums of squares decomposition
    grand_mean = long['y'].mean()
    n_total = len(long)
    ss_total = ((long['y'] - grand_mean) ** 2).sum()

    # Group main effect
    group_means = long.groupby('group')['y'].mean()
    ns_group = long.groupby('group')['y'].count()
    ss_group = sum(ns_group[g] * (group_means[g] - grand_mean) ** 2
                    for g in group_means.index)
    df_group = len(group_means) - 1

    # Time main effect
    time_means = long.groupby('time')['y'].mean()
    ns_time = long.groupby('time')['y'].count()
    ss_time = sum(ns_time[t] * (time_means[t] - grand_mean) ** 2
                   for t in time_means.index)
    df_time = len(time_means) - 1

    # Cell means
    cell_means = long.groupby(['group', 'time'])['y'].mean()
    ns_cell = long.groupby(['group', 'time'])['y'].count()
    ss_cells = sum(ns_cell.loc[(g, t)] * (cell_means.loc[(g, t)] - grand_mean) ** 2
                    for g in group_means.index for t in time_means.index)
    ss_interaction = ss_cells - ss_group - ss_time
    df_interaction = df_group * df_time

    # Error
    ss_within_cells = ((long['y'] - long.groupby(['group', 'time'])['y']
                                          .transform('mean')) ** 2).sum()
    df_error = n_total - len(cell_means)

    # F-ratios
    ms_group = ss_group / df_group if df_group > 0 else 0
    ms_time = ss_time / df_time if df_time > 0 else 0
    ms_interaction = ss_interaction / df_interaction if df_interaction > 0 else 0
    ms_error = ss_within_cells / df_error if df_error > 0 else 0

    f_group = ms_group / ms_error if ms_error > 0 else 0
    f_time = ms_time / ms_error if ms_error > 0 else 0
    f_interaction = ms_interaction / ms_error if ms_error > 0 else 0

    # p-values
    p_group = 1 - stats.f.cdf(f_group, df_group, df_error)
    p_time = 1 - stats.f.cdf(f_time, df_time, df_error)
    p_interaction = 1 - stats.f.cdf(f_interaction, df_interaction, df_error)

    return {
        'time':   {'F': float(f_time), 'p': float(p_time),
                   'df1': df_time, 'df2': df_error,
                   'eta2_p': partial_eta_squared(ss_time, ss_within_cells)},
        'group':  {'F': float(f_group), 'p': float(p_group),
                   'df1': df_group, 'df2': df_error,
                   'eta2_p': partial_eta_squared(ss_group, ss_within_cells)},
        'time_x_group': {'F': float(f_interaction), 'p': float(p_interaction),
                         'df1': df_interaction, 'df2': df_error,
                         'eta2_p': partial_eta_squared(ss_interaction, ss_within_cells)},
    }


def post_hoc_bonferroni(values_by_group: dict) -> pd.DataFrame:
    """Pairwise t-tests with Bonferroni correction.

    values_by_group: dict mapping group label → array of values
    Returns a DataFrame with columns: group_a, group_b, mean_diff, t, p_raw, p_bonf
    """
    groups = list(values_by_group.keys())
    pairs = list(combinations(groups, 2))
    rows = []
    n_comparisons = len(pairs)
    for a, b in pairs:
        va, vb = np.asarray(values_by_group[a]), np.asarray(values_by_group[b])
        t, p = stats.ttest_ind(va, vb, equal_var=False)
        rows.append({
            'group_a': a, 'group_b': b,
            'mean_diff': float(va.mean() - vb.mean()),
            't': float(t), 'p_raw': float(p),
            'p_bonf': min(float(p) * n_comparisons, 1.0),
        })
    return pd.DataFrame(rows)


def chi_squared_proportions(counts: np.ndarray) -> Tuple[float, float]:
    """Chi-square test on a vector of counts vs uniform expectation."""
    counts = np.asarray(counts, dtype=float)
    expected = counts.sum() / len(counts)
    chi2 = ((counts - expected) ** 2 / expected).sum()
    p = 1 - stats.chi2.cdf(chi2, df=len(counts) - 1)
    return float(chi2), float(p)


def paired_t_test(pre: np.ndarray, post: np.ndarray) -> dict:
    """Paired t-test with 95% CI on the mean difference."""
    pre, post = np.asarray(pre, dtype=float), np.asarray(post, dtype=float)
    diff = post - pre
    n = len(diff)
    mean_d = diff.mean()
    sd_d = diff.std(ddof=1)
    se = sd_d / np.sqrt(n)
    t = mean_d / se if se > 0 else 0
    p = 2 * (1 - stats.t.cdf(abs(t), df=n - 1))
    ci_lo = mean_d - stats.t.ppf(0.975, df=n - 1) * se
    ci_hi = mean_d + stats.t.ppf(0.975, df=n - 1) * se
    return {'mean_diff': float(mean_d), 'sd_diff': float(sd_d),
            't': float(t), 'p': float(p),
            'ci': (float(ci_lo), float(ci_hi)), 'n': n}


def mediation_test(x: np.ndarray, m: np.ndarray, y: np.ndarray,
                    n_boot: int = 2000, seed: int = 42) -> dict:
    """Baron–Kenny mediation with bootstrap CI on the indirect effect (a*b).

    Returns dict with: a, b, c (total), c_prime (direct), indirect (a*b),
    indirect_ci (95%), proportion mediated.
    """
    rng = np.random.default_rng(seed)
    x = np.asarray(x, dtype=float)
    m = np.asarray(m, dtype=float)
    y = np.asarray(y, dtype=float)

    def _regress(_y, _x):
        # Simple OLS slope
        xm = _x - _x.mean()
        ym = _y - _y.mean()
        b = (xm * ym).sum() / (xm ** 2).sum()
        return b

    a = _regress(m, x)
    # Multiple regression of y on x and m
    X = np.column_stack([np.ones_like(x), x, m])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    c_prime, b = float(coef[1]), float(coef[2])
    c = _regress(y, x)
    indirect = a * b
    pct = (indirect / c * 100) if c != 0 else float('nan')

    # Bootstrap CI on indirect
    indirect_boot = np.zeros(n_boot)
    n = len(x)
    for i in range(n_boot):
        idx = rng.integers(0, n, size=n)
        a_b = _regress(m[idx], x[idx])
        X_b = np.column_stack([np.ones(n), x[idx], m[idx]])
        coef_b, *_ = np.linalg.lstsq(X_b, y[idx], rcond=None)
        indirect_boot[i] = a_b * coef_b[2]
    ci_lo, ci_hi = np.percentile(indirect_boot, [2.5, 97.5])
    return {
        'a': float(a), 'b': float(b), 'c': float(c), 'c_prime': float(c_prime),
        'indirect': float(indirect), 'indirect_ci': (float(ci_lo), float(ci_hi)),
        'pct_mediated': float(pct),
    }
