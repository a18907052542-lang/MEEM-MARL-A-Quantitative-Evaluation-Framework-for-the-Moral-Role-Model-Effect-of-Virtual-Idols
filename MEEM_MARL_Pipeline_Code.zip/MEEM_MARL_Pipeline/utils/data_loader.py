"""
Unified data loader for the experimental raw_data.xlsx.
Provides typed accessors for each of the 11 sheets and convenience routines
for filtering to effective subjects and reshaping to long format.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from functools import lru_cache

from config import DATA_PATH, GROUP_MAP, GROUP_ORDER_CN


SHEET_NAMES = {
    'meta': '00_数据说明',
    'demo': '01_受试者基本信息',
    'mc':   '02_道德认知测试_原始分数',
    'me':   '03_道德情感量表MES_R_条目',
    'bi':   '04_亲社会行为量表PTM_条目',
    'eye':  '05_眼动追踪数据',
    'phys': '06_生理指标数据',
    'face': '07_面部表情识别数据',
    'log':  '08_系统交互日志',
    'subj': '09_主观体验量表',
    'item': '10_道德知识测试_题库',
}


@lru_cache(maxsize=1)
def load_raw_data(path: Path = DATA_PATH) -> dict:
    """Load all sheets from the raw_data.xlsx into a dict of DataFrames.
    Cached so repeated calls are cheap.
    """
    if not path.exists():
        raise FileNotFoundError(f'Raw data file not found: {path}')
    xl = pd.ExcelFile(path)
    return {key: pd.read_excel(xl, sheet_name=name)
            for key, name in SHEET_NAMES.items() if name in xl.sheet_names}


def _attach_group_en(df: pd.DataFrame) -> pd.DataFrame:
    """Add an English-language group column for convenience in analyses."""
    if '分组' in df.columns and 'group' not in df.columns:
        df = df.copy()
        df['group'] = df['分组'].map(GROUP_MAP)
    return df


def load_demographics() -> pd.DataFrame:
    """Sheet 01 — 198 recruited subjects with demographic variables."""
    df = load_raw_data()['demo']
    return _attach_group_en(df)


def get_effective_subjects() -> pd.DataFrame:
    """Filter demographics to the 186 effective subjects (completed all tests)."""
    df = load_demographics()
    return df[df['完成状态'] == '完成所有测试'].copy().reset_index(drop=True)


def load_moral_cognition() -> pd.DataFrame:
    """Sheet 02 — 50 MCQ + 10 SJT moral cognition scores at 4 time points."""
    df = load_raw_data()['mc']
    return _attach_group_en(df)


def load_moral_emotion() -> pd.DataFrame:
    """Sheet 03 — MES-R 12 items × 4 time points."""
    df = load_raw_data()['me']
    return _attach_group_en(df)


def load_behavioral_intention() -> pd.DataFrame:
    """Sheet 04 — PTM 25 items × 4 time points."""
    df = load_raw_data()['bi']
    return _attach_group_en(df)


def load_eye_tracking() -> pd.DataFrame:
    """Sheet 05 — eye-tracking session-level features."""
    df = load_raw_data()['eye']
    return _attach_group_en(df)


def load_physiological() -> pd.DataFrame:
    """Sheet 06 — HRV / SCL / EEG."""
    df = load_raw_data()['phys']
    return _attach_group_en(df)


def load_facial() -> pd.DataFrame:
    """Sheet 07 — facial expression recognition + AUs."""
    df = load_raw_data()['face']
    return _attach_group_en(df)


def load_engagement() -> pd.DataFrame:
    """Sheet 08 — system interaction logs."""
    df = load_raw_data()['log']
    return _attach_group_en(df)


def load_subjective() -> pd.DataFrame:
    """Sheet 09 — subjective experience: social presence, immersion, engagement."""
    df = load_raw_data()['subj']
    return _attach_group_en(df)


def build_long_format(measure: str = 'mc') -> pd.DataFrame:
    """Reshape a wide measure (mc / me / bi) into long format for ANOVA.

    Returns columns: 受试者编号, group, time, value
    """
    measure_loaders = {
        'mc': (load_moral_cognition, ['T0_总分(0-100)', 'T1_总分(0-100)',
                                       'T2_4wk_总分(0-100)', 'T2_8wk_总分(0-100)']),
        'me': (load_moral_emotion,   ['T0_总均分', 'T1_总均分',
                                       'T2_4wk_总均分', 'T2_8wk_总均分']),
        'bi': (load_behavioral_intention, ['T0_总均分', 'T1_总均分',
                                            'T2_4wk_总均分', 'T2_8wk_总均分']),
    }
    if measure not in measure_loaders:
        raise ValueError(f'Unknown measure: {measure}')
    loader, value_cols = measure_loaders[measure]
    df = loader()
    long = df.melt(id_vars=['受试者编号', '分组', 'group'],
                   value_vars=value_cols,
                   var_name='time_raw', value_name='value')
    time_map = {value_cols[0]: 'T0', value_cols[1]: 'T1',
                value_cols[2]: 'T2_4wk', value_cols[3]: 'T2_8wk'}
    long['time'] = long['time_raw'].map(time_map)
    return long.drop(columns=['time_raw'])


def summarize_by_group(df: pd.DataFrame, value_col: str,
                       group_col: str = '分组') -> pd.DataFrame:
    """Compute n, mean, std per group for a numeric column."""
    summary = (df.groupby(group_col)[value_col]
                 .agg(['count', 'mean', 'std'])
                 .reindex(GROUP_ORDER_CN))
    summary.columns = ['n', 'mean', 'sd']
    summary['mean_sd_str'] = (summary['mean'].round(2).astype(str)
                              + ' ± '
                              + summary['sd'].round(2).astype(str))
    return summary
