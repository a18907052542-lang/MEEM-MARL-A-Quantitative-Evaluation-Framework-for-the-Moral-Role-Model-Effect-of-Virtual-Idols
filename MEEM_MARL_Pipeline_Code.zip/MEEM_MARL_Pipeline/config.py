"""
MEEM-MARL Pipeline — Global Configuration
Encapsulates paths, hyperparameters, group labels, and target paper statistics.
"""
from pathlib import Path

# ---------- Paths ----------
ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / 'data' / 'raw_data.xlsx'
RESULTS_DIR = ROOT / 'results'
TABLES_DIR = RESULTS_DIR / 'tables'
FIGURES_DIR = RESULTS_DIR / 'figures'

for d in (TABLES_DIR, FIGURES_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ---------- Group labels ----------
GROUPS_CN = ['控制组', '虚拟偶像组', '传统教学组']
GROUPS_EN = ['Control', 'Virtual Idol', 'Traditional']
GROUP_MAP = dict(zip(GROUPS_CN, GROUPS_EN))
GROUP_ORDER_CN = ['控制组', '虚拟偶像组', '传统教学组']
GROUP_ORDER_EN = ['Control', 'Virtual Idol', 'Traditional']

# Group sample sizes (effective)
N_CTRL = 62
N_VI = 63
N_TRAD = 61
N_TOTAL = N_CTRL + N_VI + N_TRAD  # 186

# ---------- Color palette ----------
COLOR_CTRL = '#7f8c8d'      # grey
COLOR_VI = '#e74c3c'        # red (virtual idol — emphasis)
COLOR_TRAD = '#3498db'      # blue
COLOR_PALETTE = {
    'Control': COLOR_CTRL,
    'Virtual Idol': COLOR_VI,
    'Traditional': COLOR_TRAD,
    '控制组': COLOR_CTRL,
    '虚拟偶像组': COLOR_VI,
    '传统教学组': COLOR_TRAD,
}

# ---------- MEEM-MARL Hyperparameters (from paper) ----------
# Step 1: Preprocessing
MEDIAN_FILTER_WINDOW = 5
SLIDING_WINDOW_SIZE = 2.0   # seconds
SLIDING_WINDOW_OVERLAP = 0.5

# Step 2: Feature extraction dimensions
DIM_EYE = 64
DIM_FACE = 128
DIM_VOICE = 96
DIM_PHYS = 96
DIM_LOG = 32
DIM_FUSED = 256

# Step 3: Attention fusion
ATT_HIDDEN = 64

# Step 4: Affective estimator
N_EMOTIONS = 7              # 7 basic emotions (Ekman)
HIDDEN_LSTM = 128

# Step 5: Moral modeling
DIM_MORAL_LATENT = 64

# Step 7: Q-learning
Q_LEARNING_RATE = 0.05
Q_DISCOUNT_GAMMA = 0.9
N_ACTIONS = 4               # {expression, tone, content, pacing}
ACTION_SPACE = ['expression', 'tone', 'content', 'pacing']
REWARD_WEIGHTS = {'mc': 0.35, 'me': 0.35, 'bi': 0.20, 'cl': -0.10}

# Step 8: Recommender
N_CONTENT_ITEMS = 12        # 4 weeks × 3 sessions

# Step 9: Effect quantification
TARGET_COHEN_D = {
    'Virtual Idol': 0.92,
    'Traditional': 0.54,
    'Control': 0.18,
}

# ---------- Paper-reported target statistics (for cross-validation) ----------
TARGET_MORAL_COGNITION = {
    'Control':       {'pre': (48.3, 8.6),  'post': (52.8, 9.2),  'followup': (54.1, 8.9)},
    'Virtual Idol':  {'pre': (48.2, 9.1),  'post': (68.7, 10.3), 'followup': (71.3, 9.8)},
    'Traditional':   {'pre': (48.6, 8.8),  'post': (59.4, 9.7),  'followup': (60.2, 9.4)},
}

TARGET_MORAL_EMOTION = {
    'Control':      {'pre': (4.03, 0.71), 'post': (4.50, 0.68)},
    'Virtual Idol': {'pre': (4.05, 0.69), 'post': (5.82, 0.73)},
    'Traditional':  {'pre': (4.08, 0.72), 'post': (5.24, 0.70)},
}

TARGET_BEHAV_INTENT = {
    'Control':      {'pre': (3.92, 0.81), 'post': (4.18, 0.79)},
    'Virtual Idol': {'pre': (3.94, 0.83), 'post': (5.51, 0.86)},
    'Traditional':  {'pre': (3.90, 0.80), 'post': (4.82, 0.82)},
}

TARGET_ENGAGEMENT = {
    'Control':      {'duration': (15.8, 5.2), 'completion': 42, 'interaction': (12.4, 4.6),  'return': 35.5, 'coverage': (68.3, 12.4)},
    'Virtual Idol': {'duration': (28.6, 7.3), 'completion': 78, 'interaction': (35.7, 8.9),  'return': 82.5, 'coverage': (92.7, 8.6)},
    'Traditional':  {'duration': (21.3, 6.1), 'completion': 61, 'interaction': (22.3, 6.8),  'return': 57.4, 'coverage': (78.5, 10.2)},
}

TARGET_PHYSIOLOGICAL = {
    'Control':      {'pa': (3.42, 0.68), 'na': (2.86, 0.73), 'sp': (2.95, 0.82), 'im': (3.18, 0.77), 'hrv': (42.3, 8.6), 'scl': (3.82, 0.95)},
    'Virtual Idol': {'pa': (4.83, 0.71), 'na': (1.92, 0.61), 'sp': (5.26, 0.88), 'im': (5.42, 0.83), 'hrv': (58.7, 9.2), 'scl': (5.46, 1.12)},
    'Traditional':  {'pa': (4.12, 0.65), 'na': (2.34, 0.68), 'sp': (3.87, 0.79), 'im': (4.05, 0.75), 'hrv': (48.5, 8.8), 'scl': (4.38, 1.03)},
}

# Retention rates at 2/4/8 weeks (Table 10)
TARGET_RETENTION = {
    '2wk':  {'Control': {'cog': 85.3, 'emo': 78.6, 'beh': 72.4},
             'Virtual Idol': {'cog': 97.2, 'emo': 93.8, 'beh': 91.5},
             'Traditional': {'cog': 91.6, 'emo': 86.4, 'beh': 82.3}},
    '4wk':  {'Control': {'cog': 73.2, 'emo': 65.8, 'beh': 58.3},
             'Virtual Idol': {'cog': 94.3, 'emo': 89.7, 'beh': 86.4},
             'Traditional': {'cog': 82.6, 'emo': 76.9, 'beh': 71.2}},
    '8wk':  {'Control': {'cog': 60.3, 'emo': 52.7, 'beh': 45.1},
             'Virtual Idol': {'cog': 86.2, 'emo': 81.5, 'beh': 77.3},
             'Traditional': {'cog': 71.8, 'emo': 65.4, 'beh': 58.9}},
}

# SEM fit targets
TARGET_SEM_FIT = {
    'chi2_df': 2.18,
    'cfi': 0.963,
    'tli': 0.952,
    'rmsea': 0.059,
}

# Mediation effect targets (Table 7)
TARGET_MEDIATION = {
    'VI_SP_ME':       {'direct': 0.23, 'indirect': 0.35, 'total': 0.58, 'pct': 60.3},
    'VI_ENG_MC':      {'direct': 0.31, 'indirect': 0.18, 'total': 0.49, 'pct': 36.7},
    'VI_EM_BI':       {'direct': 0.26, 'indirect': 0.29, 'total': 0.55, 'pct': 52.7},
    'VI_Multiple_LO': {'direct': 0.15, 'indirect': 0.48, 'total': 0.63, 'pct': 76.2},
}

# Reproducibility seed
SEED = 20241218
