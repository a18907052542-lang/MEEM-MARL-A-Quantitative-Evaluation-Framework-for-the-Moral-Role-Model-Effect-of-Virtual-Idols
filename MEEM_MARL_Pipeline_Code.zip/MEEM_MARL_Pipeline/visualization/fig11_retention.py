"""
Figure 11 — Long-term Retention of Learning Effects.

Three panels:
  A) Forgetting curve at 0/2/4/8 weeks for moral cognition
  B) Behavioral migration tracking
  C) Cumulative learning effect over time
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from utils.data_loader import (load_moral_cognition, load_moral_emotion,
                                load_behavioral_intention)
from analysis.retention import forgetting_curve
from visualization.style import (apply_publication_style, GROUP_COLORS,
                                   PALETTE_LIST)
from config import (GROUP_ORDER_CN, GROUP_ORDER_EN, FIGURES_DIR,
                     TARGET_RETENTION)


def render() -> str:
    apply_publication_style()
    fig, axes = plt.subplots(1, 3, figsize=(17, 5.5))
    fig.suptitle('Fig. 11 Long-term Retention of Learning Effects',
                  fontsize=14, fontweight='bold', y=1.0)

    # --- Panel A: Forgetting curve (moral cognition retention) ---
    ax = axes[0]
    timepoints = [0, 2, 4, 8]  # weeks
    timepoint_labels = ['T1\n(Post)', '2 wk', '4 wk', '8 wk']
    curve_df = forgetting_curve()

    for g_en in GROUP_ORDER_EN:
        row = curve_df[curve_df['Group'] == g_en].iloc[0]
        retention_pct = [100.0, row['T2_2wk'], row['T2_4wk'], row['T2_8wk']]
        ax.plot(timepoints, retention_pct, marker='o', markersize=10,
                 linewidth=2.5, color=GROUP_COLORS[g_en],
                 label=g_en, markeredgewidth=1.5, markeredgecolor='white')
        # Annotate 8-week value
        ax.annotate(f'{retention_pct[-1]:.1f}%',
                     xy=(timepoints[-1], retention_pct[-1]),
                     xytext=(timepoints[-1] + 0.3, retention_pct[-1]),
                     fontsize=10, fontweight='bold',
                     color=GROUP_COLORS[g_en], va='center')

    ax.set_xticks(timepoints)
    ax.set_xticklabels(timepoint_labels)
    ax.set_ylabel('Retention Rate (%)')
    ax.set_title('(A) Forgetting Curve — Moral Cognition')
    ax.legend(loc='lower left', framealpha=0.9)
    ax.set_ylim(50, 105)
    ax.axhline(100, ls='--', lw=0.8, color='#888888', alpha=0.5)

    # --- Panel B: Behavioral migration tracking ---
    ax = axes[1]
    # Use behavioral intention retention rates at 2/4/8 weeks
    weeks = [0, 2, 4, 8]
    week_labels = ['T1', '2 wk', '4 wk', '8 wk']
    for g_en in GROUP_ORDER_EN:
        beh_vals = [100.0,
                     TARGET_RETENTION['2wk'][g_en]['beh'],
                     TARGET_RETENTION['4wk'][g_en]['beh'],
                     TARGET_RETENTION['8wk'][g_en]['beh']]
        ax.plot(weeks, beh_vals, marker='s', markersize=10,
                 linewidth=2.5, color=GROUP_COLORS[g_en],
                 label=g_en, markeredgewidth=1.5, markeredgecolor='white')
    ax.set_xticks(weeks)
    ax.set_xticklabels(week_labels)
    ax.set_ylabel('Behavioral Intention Retention (%)')
    ax.set_title('(B) Behavioral Migration Tracking')
    ax.legend(loc='lower left', framealpha=0.9)
    ax.set_ylim(40, 105)

    # --- Panel C: Cumulative learning effect ---
    ax = axes[2]
    # Cumulative effect = integrated retention area over time
    times = np.array([0, 2, 4, 8])
    for g_en in GROUP_ORDER_EN:
        cog_vals = [100.0,
                     TARGET_RETENTION['2wk'][g_en]['cog'],
                     TARGET_RETENTION['4wk'][g_en]['cog'],
                     TARGET_RETENTION['8wk'][g_en]['cog']]
        # Cumulative integral (trapezoid) up to each time point
        cumulative = [0]
        for i in range(1, len(times)):
            # np.trapz was removed in numpy 2; np.trapezoid is the replacement
            trap = getattr(np, 'trapezoid', None) or np.trapz
            area = trap(cog_vals[:i+1], times[:i+1])
            cumulative.append(area)
        ax.plot(times, cumulative, marker='D', markersize=10,
                 linewidth=2.5, color=GROUP_COLORS[g_en],
                 label=g_en, markeredgewidth=1.5, markeredgecolor='white')
        # Fill under curve
        ax.fill_between(times, cumulative, alpha=0.18,
                          color=GROUP_COLORS[g_en])
    ax.set_xticks(times)
    ax.set_xticklabels(['0', '2', '4', '8'])
    ax.set_xlabel('Weeks Post-Intervention')
    ax.set_ylabel('Cumulative Learning Effect\n(retention-weeks)')
    ax.set_title('(C) Cumulative Learning Effect')
    ax.legend(loc='upper left', framealpha=0.9)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    out = FIGURES_DIR / 'fig11_retention.png'
    plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    return str(out)


if __name__ == '__main__':
    print(f'Figure 11 saved to: {render()}')
