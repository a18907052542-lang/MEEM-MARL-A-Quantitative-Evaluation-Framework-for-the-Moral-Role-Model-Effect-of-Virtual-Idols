"""
Figure 8 — Multi-dimensional Analysis of Learning Engagement.

Four panels:
  A) Session duration comparison with significance brackets
  B) Completion rate by group
  C) AOI fixation distribution (Avatar/Content/Controls)
  D) Interaction frequency over sessions
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from utils.data_loader import load_engagement, load_eye_tracking
from visualization.style import (apply_publication_style, PALETTE_LIST,
                                   GROUP_COLORS, annotate_significance)
from config import GROUP_ORDER_CN, GROUP_ORDER_EN, FIGURES_DIR


def render() -> str:
    apply_publication_style()
    eng = load_engagement()
    eye = load_eye_tracking()

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Fig. 8 Multi-dimensional Analysis of Learning Engagement',
                  fontsize=14, fontweight='bold', y=0.995)

    # --- Panel A: Session duration with significance brackets ---
    ax = axes[0, 0]
    dur_subj = eng.groupby(['受试者编号', '分组'])['会话时长(分钟)'].mean().reset_index()
    means = [dur_subj[dur_subj['分组'] == g]['会话时长(分钟)'].mean()
              for g in GROUP_ORDER_CN]
    sems = [dur_subj[dur_subj['分组'] == g]['会话时长(分钟)'].sem()
              for g in GROUP_ORDER_CN]
    bars = ax.bar(GROUP_ORDER_EN, means, color=PALETTE_LIST,
                   yerr=sems, capsize=8, edgecolor='white', linewidth=1.2)
    for bar, v in zip(bars, means):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.8,
                 f'{v:.1f}', ha='center', fontsize=11, fontweight='bold')
    ax.set_ylim(0, max(means) * 1.30)
    ax.set_ylabel('Session Duration (min)')
    ax.set_title('(A) Average Session Duration')
    # Significance brackets
    annotate_significance(ax, 0, 1, max(means) * 1.07, 0.0001, height_step=0.5)
    annotate_significance(ax, 1, 2, max(means) * 1.15, 0.0001, height_step=0.5)
    annotate_significance(ax, 0, 2, max(means) * 1.22, 0.0001, height_step=0.5)

    # --- Panel B: Completion behavior flow / completion rates ---
    ax = axes[0, 1]
    comp_rate = (eng.groupby('分组')['是否完成(1=是)'].mean() * 100)
    return_rate = (eng.groupby('分组')['是否在24h内回访'].mean() * 100)
    x = np.arange(3)
    width = 0.38
    bars1 = ax.bar(x - width/2,
                    [comp_rate[g] for g in GROUP_ORDER_CN],
                    width, color=PALETTE_LIST, edgecolor='white',
                    linewidth=1.2, label='Completion Rate')
    bars2 = ax.bar(x + width/2,
                    [return_rate[g] for g in GROUP_ORDER_CN],
                    width, color=PALETTE_LIST, edgecolor='white',
                    linewidth=1.2, alpha=0.55, hatch='//',
                    label='24h Return Rate')
    ax.set_xticks(x)
    ax.set_xticklabels(GROUP_ORDER_EN)
    ax.set_ylabel('Percentage (%)')
    ax.set_title('(B) Completion & Return Rates')
    ax.set_ylim(0, 100)
    for bars in (bars1, bars2):
        for bar in bars:
            v = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2, v + 1.5,
                     f'{v:.0f}', ha='center', fontsize=9, fontweight='bold')
    ax.legend(loc='upper left', framealpha=0.9, fontsize=9)

    # --- Panel C: AOI fixation distribution (stacked bar) ---
    ax = axes[1, 0]
    aoi_data = {}
    for g_cn, g_en in zip(GROUP_ORDER_CN, GROUP_ORDER_EN):
        sub = eye[eye['分组'] == g_cn]
        aoi_data[g_en] = {
            'Avatar/Face':  sub['AOI_虚拟形象/教师区(%)'].mean(),
            'Content':      sub['AOI_内容/课件区(%)'].mean(),
            'Controls':     sub['AOI_控件/界面区(%)'].mean(),
        }
    aoi_df = pd.DataFrame(aoi_data).T
    aoi_colors = ['#e74c3c', '#3498db', '#95a5a6']
    bottom = np.zeros(3)
    for i, col in enumerate(aoi_df.columns):
        vals = aoi_df[col].values
        bars = ax.bar(GROUP_ORDER_EN, vals, bottom=bottom,
                       color=aoi_colors[i], edgecolor='white',
                       linewidth=1.5, label=col, width=0.65)
        for j, v in enumerate(vals):
            ax.text(j, bottom[j] + v/2, f'{v:.1f}%',
                     ha='center', va='center', fontsize=9,
                     color='white', fontweight='bold')
        bottom += vals
    ax.set_ylabel('AOI Fixation Distribution (%)')
    ax.set_title('(C) AOI Fixation Distribution')
    ax.legend(loc='upper right', framealpha=0.9, fontsize=9,
               bbox_to_anchor=(1.0, 1.0))
    ax.set_ylim(0, 110)

    # --- Panel D: Interaction frequency over sessions ---
    ax = axes[1, 1]
    sessions = sorted(eng['会话编号'].unique()) if '会话编号' in eng.columns else ['Session1', 'Session2', 'Session3']
    for g_cn, g_en in zip(GROUP_ORDER_CN, GROUP_ORDER_EN):
        sub = eng[eng['分组'] == g_cn]
        means = []
        sems = []
        for s in sessions:
            session_data = sub[sub['会话编号'] == s]['交互频次(次)'] if '会话编号' in sub.columns else pd.Series([sub['交互频次(次)'].mean()])
            means.append(session_data.mean())
            sems.append(session_data.sem() if len(session_data) > 1 else 0)
        ax.errorbar(range(len(sessions)), means, yerr=sems,
                     marker='o', markersize=10, linewidth=2.5,
                     color=GROUP_COLORS[g_en], label=g_en, capsize=5,
                     markeredgewidth=1.5, markeredgecolor='white')
    ax.set_xticks(range(len(sessions)))
    ax.set_xticklabels(sessions)
    ax.set_ylabel('Interaction Frequency')
    ax.set_title('(D) Interaction Frequency Across Sessions')
    ax.legend(loc='best', framealpha=0.9)

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    out = FIGURES_DIR / 'fig8_engagement.png'
    plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    return str(out)


if __name__ == '__main__':
    print(f'Figure 8 saved to: {render()}')
