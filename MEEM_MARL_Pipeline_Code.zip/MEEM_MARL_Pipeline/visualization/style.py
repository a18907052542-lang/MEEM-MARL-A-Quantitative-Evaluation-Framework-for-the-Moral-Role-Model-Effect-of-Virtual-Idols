"""
Shared matplotlib styling for all figures.
Implements a publication-quality palette consistent across Figures 6-11.
"""
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns

from config import (COLOR_CTRL, COLOR_VI, COLOR_TRAD, COLOR_PALETTE)

# Color palette for the three groups
GROUP_COLORS = {
    'Control':      COLOR_CTRL,
    'Virtual Idol': COLOR_VI,
    'Traditional':  COLOR_TRAD,
}

PALETTE_LIST = [COLOR_CTRL, COLOR_VI, COLOR_TRAD]

# Additional accents for paths / mediation arrows
ACCENT_PRIMARY = '#1F4E78'
ACCENT_SECONDARY = '#2E75B6'
ACCENT_TERTIARY = '#9B59B6'
LIGHT_GREY = '#ecf0f1'
DARK_GREY = '#2c3e50'


def apply_publication_style():
    """Apply standardized matplotlib parameters for publication-quality figures."""
    mpl.rcParams.update({
        'figure.dpi': 100,
        'savefig.dpi': 300,
        'figure.figsize': (10, 6),
        'font.family': 'DejaVu Sans',
        'font.size': 10,
        'axes.titlesize': 12,
        'axes.titleweight': 'bold',
        'axes.labelsize': 10,
        'axes.linewidth': 1.2,
        'axes.spines.top': False,
        'axes.spines.right': False,
        'axes.grid': True,
        'grid.alpha': 0.25,
        'grid.linestyle': '--',
        'grid.linewidth': 0.6,
        'xtick.labelsize': 9,
        'ytick.labelsize': 9,
        'legend.fontsize': 9,
        'legend.frameon': True,
        'legend.framealpha': 0.9,
        'legend.edgecolor': '#bbbbbb',
        'lines.linewidth': 2.0,
        'patch.edgecolor': 'white',
        'patch.linewidth': 0.8,
    })
    sns.set_context('paper', font_scale=1.0)


def annotate_significance(ax, x1, x2, y, p_value, height_step=0.02):
    """Draw a significance bracket between x1 and x2 at height y on the axes."""
    if p_value < 0.001:
        stars = '***'
    elif p_value < 0.01:
        stars = '**'
    elif p_value < 0.05:
        stars = '*'
    else:
        stars = 'ns'
    h = y + height_step
    ax.plot([x1, x1, x2, x2], [y, h, h, y], lw=1.0, c='black')
    ax.text((x1 + x2) / 2, h, stars, ha='center', va='bottom', fontsize=11,
             fontweight='bold')


def make_group_legend_handles(colors=None):
    """Return matplotlib handles for a three-group legend."""
    from matplotlib.patches import Patch
    if colors is None:
        colors = [COLOR_CTRL, COLOR_VI, COLOR_TRAD]
    labels = ['Control', 'Virtual Idol', 'Traditional']
    return [Patch(facecolor=c, edgecolor='white', label=l)
            for c, l in zip(colors, labels)]
