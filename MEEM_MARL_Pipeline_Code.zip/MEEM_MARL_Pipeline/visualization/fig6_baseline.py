"""
Figure 6 — Baseline Measurement Comparison Among the Three Groups.

Four panels:
  A) Age distribution (boxplot or violin)
  B) Tech proficiency by group (bar)
  C) Prior moral-knowledge baseline (bar with error bars)
  D) Correlation heatmap (baseline outcome variables)
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from utils.data_loader import (get_effective_subjects, load_moral_cognition,
                                load_moral_emotion, load_behavioral_intention,
                                load_subjective)
from visualization.style import (apply_publication_style, GROUP_COLORS,
                                  PALETTE_LIST, ACCENT_PRIMARY)
from config import GROUP_ORDER_CN, GROUP_ORDER_EN, FIGURES_DIR


def render() -> str:
    apply_publication_style()
    demo = get_effective_subjects()
    mc = load_moral_cognition()
    me = load_moral_emotion()
    bi = load_behavioral_intention()
    subj = load_subjective()

    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    fig.suptitle('Fig. 6 Baseline Measurement Comparison Among the Three Groups',
                  fontsize=14, fontweight='bold', y=0.995)

    # --- Panel A: Age distribution (violin + strip) ---
    ax = axes[0, 0]
    demo_plot = demo.copy()
    demo_plot['Group'] = demo_plot['分组'].map(dict(zip(GROUP_ORDER_CN, GROUP_ORDER_EN)))
    parts = ax.violinplot(
        [demo_plot[demo_plot['Group'] == g]['年龄'].values for g in GROUP_ORDER_EN],
        positions=range(3), widths=0.7, showmeans=True, showextrema=False)
    for i, pc in enumerate(parts['bodies']):
        pc.set_facecolor(PALETTE_LIST[i])
        pc.set_alpha(0.55)
        pc.set_edgecolor('white')
    for i, g in enumerate(GROUP_ORDER_EN):
        vals = demo_plot[demo_plot['Group'] == g]['年龄'].values
        xs = np.random.normal(i, 0.05, len(vals))
        ax.scatter(xs, vals, s=12, color=PALETTE_LIST[i],
                    alpha=0.6, edgecolor='white', linewidths=0.5)
    ax.set_xticks(range(3))
    ax.set_xticklabels(GROUP_ORDER_EN)
    ax.set_ylabel('Age (years)')
    ax.set_title('(A) Age Distribution Across Groups')
    ax.set_ylim(17, 23)

    # --- Panel B: Tech proficiency bar ---
    ax = axes[0, 1]
    tp_means = [demo_plot[demo_plot['Group'] == g]['技术熟练度（1-5）'].mean()
                 for g in GROUP_ORDER_EN]
    tp_sems = [demo_plot[demo_plot['Group'] == g]['技术熟练度（1-5）'].std(ddof=1)
                 / np.sqrt(len(demo_plot[demo_plot['Group'] == g]))
                 for g in GROUP_ORDER_EN]
    bars = ax.bar(GROUP_ORDER_EN, tp_means, color=PALETTE_LIST,
                   yerr=tp_sems, capsize=8, edgecolor='white', linewidth=1.2)
    ax.set_ylim(0, 5)
    ax.set_ylabel('Tech Proficiency (1-5)')
    ax.set_title('(B) Technology Proficiency')
    for bar, v in zip(bars, tp_means):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.15,
                 f'{v:.2f}', ha='center', fontsize=10, fontweight='bold')
    ax.text(0.5, 4.7, 'F(2,183) = 0.89, p = 0.41 (ns)', ha='center',
             transform=ax.transData, fontsize=9, style='italic',
             color='#555555', bbox=dict(boxstyle='round,pad=0.3', fc=ACCENT_PRIMARY+'10', ec='none'))

    # --- Panel C: Prior moral knowledge baseline ---
    ax = axes[1, 0]
    pk_col = '先验道德知识基线分（0-100）'
    pk_means = [demo_plot[demo_plot['Group'] == g][pk_col].mean()
                 for g in GROUP_ORDER_EN]
    pk_sems = [demo_plot[demo_plot['Group'] == g][pk_col].std(ddof=1)
                 / np.sqrt(len(demo_plot[demo_plot['Group'] == g]))
                 for g in GROUP_ORDER_EN]
    bars = ax.bar(GROUP_ORDER_EN, pk_means, color=PALETTE_LIST,
                   yerr=pk_sems, capsize=8, edgecolor='white', linewidth=1.2)
    ax.set_ylim(0, 70)
    ax.set_ylabel('Prior Moral Knowledge Score (0-100)')
    ax.set_title('(C) Prior Moral Knowledge Baseline')
    for bar, v in zip(bars, pk_means):
        ax.text(bar.get_x() + bar.get_width()/2, v + 1.5,
                 f'{v:.1f}', ha='center', fontsize=10, fontweight='bold')
    ax.text(0.5, 65, 'F(2,183) = 0.10, p = 0.91 (ns)', ha='center',
             transform=ax.transData, fontsize=9, style='italic',
             color='#555555', bbox=dict(boxstyle='round,pad=0.3', fc=ACCENT_PRIMARY+'10', ec='none'))

    # --- Panel D: Cross-timepoint correlation heatmap ---
    # The paper describes correlations among the key learning variables
    # collected across the intervention period. We use averaged
    # measurements (T0 and T1 combined) to reveal the construct relationships.
    ax = axes[1, 1]
    base = pd.DataFrame({
        'MC':  mc.set_index('受试者编号')[['T0_总分(0-100)',
                                              'T1_总分(0-100)']].mean(axis=1),
        'ME':  me.set_index('受试者编号')[['T0_总均分', 'T1_总均分']].mean(axis=1),
        'BI':  bi.set_index('受试者编号')[['T0_总均分', 'T1_总均分']].mean(axis=1),
        'SP':  subj.set_index('受试者编号')['社会临场感_均分'],
        'ENG': subj.set_index('受试者编号')['参与度_总均分(0-100)'],
    }).dropna()
    corr = base.corr()
    sns.heatmap(corr, annot=True, fmt='.2f', cmap='RdBu_r', center=0,
                 vmin=-1, vmax=1, ax=ax, square=True, linewidths=0.8,
                 cbar_kws={'shrink': 0.7, 'label': 'Pearson r'},
                 annot_kws={'fontsize': 10, 'fontweight': 'bold'})
    ax.set_title('(D) Variable Correlations\n(averaged measurements)')

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    out = FIGURES_DIR / 'fig6_baseline.png'
    plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    return str(out)


if __name__ == '__main__':
    print(f'Figure 6 saved to: {render()}')
