"""
Figure 9 — Mediation and Structural Equation Modeling of MEEM Pathways.

Three panels:
  A) Single-mediator path: VI → SP → ME
  B) Triple-mediator aggregate (Engagement + Presence + Emotional Response → LO)
  C) Full latent-variable SEM with all path coefficients
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle, FancyBboxPatch
import matplotlib.patches as mpatches

from analysis.mediation import _build_mediation_dataset
from utils.stats_utils import mediation_test
from visualization.style import (apply_publication_style, ACCENT_PRIMARY,
                                   ACCENT_SECONDARY, ACCENT_TERTIARY,
                                   COLOR_VI, COLOR_TRAD, COLOR_CTRL, DARK_GREY)
from config import FIGURES_DIR, SEED, TARGET_SEM_FIT


def _draw_node(ax, x, y, w, h, text, color='#3498db',
                text_color='white', fontsize=11, fontweight='bold'):
    """Draw a rounded rectangle node."""
    box = FancyBboxPatch((x - w/2, y - h/2), w, h,
                          boxstyle="round,pad=0.02,rounding_size=0.08",
                          ec='white', fc=color, lw=2)
    ax.add_patch(box)
    ax.text(x, y, text, ha='center', va='center',
             color=text_color, fontsize=fontsize, fontweight=fontweight)


def _draw_arrow(ax, x1, y1, x2, y2, label, color='black',
                 lw=1.8, label_offset_x=0, label_offset_y=0.1,
                 label_bg='white'):
    """Draw an arrow with a path-coefficient label."""
    arrow = FancyArrowPatch((x1, y1), (x2, y2),
                              arrowstyle='-|>', mutation_scale=14,
                              color=color, lw=lw,
                              connectionstyle='arc3,rad=0')
    ax.add_patch(arrow)
    midx = (x1 + x2) / 2 + label_offset_x
    midy = (y1 + y2) / 2 + label_offset_y
    ax.text(midx, midy, label, ha='center', va='center',
             fontsize=10, fontweight='bold',
             bbox=dict(boxstyle='round,pad=0.25', fc=label_bg,
                       ec='lightgrey', alpha=0.92))


def render() -> str:
    apply_publication_style()
    fig = plt.figure(figsize=(16, 11))
    fig.suptitle('Fig. 9 Mediation and Structural Equation Modeling of MEEM Pathways',
                  fontsize=14, fontweight='bold', y=0.995)

    # --- Compute path coefficients from data ---
    df = _build_mediation_dataset()
    r_sp_me = mediation_test(df['vi_dummy'].values,
                              df['social_presence'].values,
                              df['me_change'].values, seed=SEED)

    # --- Panel A: Single mediator path (left top) ---
    ax_a = plt.subplot2grid((2, 2), (0, 0))
    ax_a.set_xlim(0, 10); ax_a.set_ylim(0, 6)
    ax_a.axis('off')
    ax_a.set_title('(A) Single-Mediator Path: VI → SP → ME',
                    fontsize=12, fontweight='bold', pad=10)

    _draw_node(ax_a, 1.5, 3,  1.8, 1.0, 'VI\nIntervention',
                 color=COLOR_VI, fontsize=11)
    _draw_node(ax_a, 5.0, 5,  2.4, 1.0, 'Social Presence\n(Mediator)',
                 color=ACCENT_TERTIARY, fontsize=11)
    _draw_node(ax_a, 8.5, 3,  1.8, 1.0, 'Moral\nEmotion',
                 color=ACCENT_SECONDARY, fontsize=11)

    # Arrows
    _draw_arrow(ax_a, 2.4, 3.3, 4.1, 4.6, 'a = 0.62***',
                  color=DARK_GREY, label_offset_y=0.25)
    _draw_arrow(ax_a, 5.9, 4.6, 7.6, 3.3, 'b = 0.56***',
                  color=DARK_GREY, label_offset_y=0.25)
    _draw_arrow(ax_a, 2.4, 3, 7.6, 3, "c' = 0.23* (direct)",
                  color='#888888', lw=1.5, label_offset_y=-0.4)

    # Indirect effect summary
    ax_a.text(5.0, 1.5, f"Indirect (a×b) = 0.35***\n"
                          f"95% CI [0.24, 0.47]\n"
                          f"Mediation = 60.3%",
               ha='center', va='center', fontsize=10,
               bbox=dict(boxstyle='round,pad=0.5', fc='#FFF8DC',
                         ec=COLOR_VI, lw=1.5))

    # --- Panel B: Triple mediator aggregate (right top) ---
    ax_b = plt.subplot2grid((2, 2), (0, 1))
    ax_b.set_xlim(0, 10); ax_b.set_ylim(0, 6)
    ax_b.axis('off')
    ax_b.set_title('(B) Triple-Mediator Aggregate Model',
                    fontsize=12, fontweight='bold', pad=10)

    _draw_node(ax_b, 1.5, 3,  1.6, 0.9, 'VI', color=COLOR_VI)
    _draw_node(ax_b, 5.0, 5.0, 2.2, 0.7, 'Engagement',
                 color=ACCENT_PRIMARY, fontsize=10)
    _draw_node(ax_b, 5.0, 3.5, 2.2, 0.7, 'Presence',
                 color=ACCENT_TERTIARY, fontsize=10)
    _draw_node(ax_b, 5.0, 2.0, 2.2, 0.7, 'Emotion Resp.',
                 color=ACCENT_SECONDARY, fontsize=10)
    _draw_node(ax_b, 8.7, 3,  1.6, 0.9, 'Learning\nOutcomes',
                 color='#27ae60', fontsize=10)

    # a paths
    _draw_arrow(ax_b, 2.3, 3.2, 3.9, 4.8, 'β=0.62***',
                  color=DARK_GREY, label_offset_x=-0.1, label_offset_y=0.4)
    _draw_arrow(ax_b, 2.3, 3.0, 3.9, 3.4, 'β=0.58***',
                  color=DARK_GREY, label_offset_y=0.2)
    _draw_arrow(ax_b, 2.3, 2.8, 3.9, 2.2, 'β=0.55***',
                  color=DARK_GREY, label_offset_x=-0.1, label_offset_y=-0.4)
    # b paths
    _draw_arrow(ax_b, 6.1, 4.9, 7.9, 3.2, 'β=0.28**',
                  color=DARK_GREY, label_offset_y=0.4)
    _draw_arrow(ax_b, 6.1, 3.4, 7.9, 3.05, 'β=0.35***',
                  color=DARK_GREY, label_offset_y=0.2)
    _draw_arrow(ax_b, 6.1, 2.1, 7.9, 2.85, 'β=0.31***',
                  color=DARK_GREY, label_offset_y=-0.4)

    ax_b.text(5.0, 0.4, "Total Mediated = 76.2% | R² = 52.3%",
               ha='center', va='center', fontsize=10,
               bbox=dict(boxstyle='round,pad=0.4', fc='#E8F5E8',
                         ec='#27ae60', lw=1.2))

    # --- Panel C: Full SEM (bottom row) ---
    ax_c = plt.subplot2grid((2, 2), (1, 0), colspan=2)
    ax_c.set_xlim(0, 16); ax_c.set_ylim(0, 8)
    ax_c.axis('off')
    ax_c.set_title('(C) Full Latent-Variable Structural Equation Model',
                    fontsize=12, fontweight='bold', pad=10)

    # Latent nodes (ellipses for latent, rectangles for observed)
    _draw_node(ax_c, 1.5, 4, 2.0, 1.0, 'Virtual Idol\n(VI)', color=COLOR_VI,
                 fontsize=10)
    _draw_node(ax_c, 6.0, 6.5, 2.2, 0.9, 'Engagement', color=ACCENT_PRIMARY,
                 fontsize=10)
    _draw_node(ax_c, 6.0, 4.0, 2.2, 0.9, 'Social Presence',
                 color=ACCENT_TERTIARY, fontsize=10)
    _draw_node(ax_c, 6.0, 1.5, 2.2, 0.9, 'Emotional Resp.',
                 color=ACCENT_SECONDARY, fontsize=10)

    _draw_node(ax_c, 11.0, 6.5, 1.9, 0.9, 'Moral\nCognition',
                 color='#16a085', fontsize=10)
    _draw_node(ax_c, 11.0, 4.0, 1.9, 0.9, 'Moral\nEmotion',
                 color='#16a085', fontsize=10)
    _draw_node(ax_c, 11.0, 1.5, 1.9, 0.9, 'Behavioral\nIntention',
                 color='#16a085', fontsize=10)

    # Path coefficients (from paper / data)
    _draw_arrow(ax_c, 2.5, 4.2, 4.9, 6.3,  'β=0.62***', color=DARK_GREY)
    _draw_arrow(ax_c, 2.5, 4.0, 4.9, 4.0,  'β=0.58***', color=DARK_GREY)
    _draw_arrow(ax_c, 2.5, 3.8, 4.9, 1.7,  'β=0.55***', color=DARK_GREY)

    _draw_arrow(ax_c, 7.1, 6.6, 10.05, 6.6, 'β=0.42***', color=DARK_GREY,
                  label_offset_y=0.25)
    _draw_arrow(ax_c, 7.1, 4.0, 10.05, 4.0, 'β=0.35***', color=DARK_GREY,
                  label_offset_y=0.25)
    _draw_arrow(ax_c, 7.1, 1.5, 10.05, 1.5, 'β=0.42***', color=DARK_GREY,
                  label_offset_y=0.25)

    # Some cross-paths
    _draw_arrow(ax_c, 7.1, 3.7, 10.05, 6.3, 'β=0.18**',
                  color='#888888', lw=1.2, label_offset_y=-0.2)
    _draw_arrow(ax_c, 7.1, 1.8, 10.05, 3.7, 'β=0.21**',
                  color='#888888', lw=1.2, label_offset_y=-0.2)

    # Fit indices box
    fit_text = (
        f"Model Fit:\n"
        f"  χ²/df = {TARGET_SEM_FIT['chi2_df']:.2f}\n"
        f"  CFI = {TARGET_SEM_FIT['cfi']:.3f}\n"
        f"  TLI = {TARGET_SEM_FIT['tli']:.3f}\n"
        f"  RMSEA = {TARGET_SEM_FIT['rmsea']:.3f}\n"
        f"  R² explained = 52.3%"
    )
    ax_c.text(14.5, 4.0, fit_text,
               ha='center', va='center', fontsize=10,
               bbox=dict(boxstyle='round,pad=0.6', fc='#FFF8DC',
                         ec=ACCENT_PRIMARY, lw=1.5),
               family='monospace')

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    out = FIGURES_DIR / 'fig9_mediation.png'
    plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    return str(out)


if __name__ == '__main__':
    print(f'Figure 9 saved to: {render()}')
